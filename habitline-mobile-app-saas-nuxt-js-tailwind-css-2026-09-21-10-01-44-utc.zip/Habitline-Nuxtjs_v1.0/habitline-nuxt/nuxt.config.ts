import { defineNuxtConfig } from 'nuxt/config'
import tailwindcss from '@tailwindcss/vite'

export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  devtools: { enabled: true },

  // Nuxt 4 source directory structure config
  future: {
    compatibilityVersion: 4,
  },

  // Redirection rules
  routeRules: {
    '/': { redirect: '/home' },
  },

  // App head settings
  app: {
    head: {
      title: 'Habitline - Mobile App & SaaS Landing Page Tailwind CSS 4 Template',
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        {
          name: 'title',
          content: 'Habitline - Mobile App & SaaS Landing Page Tailwind CSS 4 Template',
        },
        {
          name: 'description',
          content:
            'Habitline is a modern and fully responsive mobile app and SaaS landing page template built with Tailwind CSS 4. Perfect for AI startups, productivity apps, software products, digital platforms, and modern web applications.',
        },
        {
          name: 'keywords',
          content:
            'mobile app template, saas landing page, tailwind css template, ai startup website, app landing page, productivity app template, software website template, startup landing page, web app template, saas html template',
        },
        { name: 'author', content: 'Unifato' },
        { name: 'robots', content: 'index, follow' },
      ],
      link: [{ rel: 'shortcut icon', href: '/images/favicon.ico' }],
    },
  },

  // Vite config for Tailwind CSS v4
  vite: {
    plugins: [tailwindcss()],
  },
})
