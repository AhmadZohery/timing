import { useHead } from '#unhead/composables'

export const usePageTitle = (pageTitle: string) => {
  useHead({
    title: `${pageTitle} | Habitline - Mobile App & SaaS Landing Page Tailwind CSS 4 Template`,
  })
}
