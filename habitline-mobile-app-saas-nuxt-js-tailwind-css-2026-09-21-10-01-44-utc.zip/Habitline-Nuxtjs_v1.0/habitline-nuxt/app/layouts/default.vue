<template>
  <div>
    <Navbar />
    <main>
      <slot />
    </main>
    <Footer />
  </div>
</template>

<script setup lang="ts">
import Navbar from '~/layouts/topbar/index.vue'
import Footer from '~/layouts/footer/index.vue'
</script>
