<template>
  <footer class="bg-body-bg pt-20 pb-5 lg:pb-7.5">
    <div class="container">
      <!-- Main Footer Grid -->
      <div class="grid grid-cols-1 justify-between gap-7.5 md:grid-cols-4 md:gap-12.5 lg:gap-32">
        <!-- Left Section: Logo & Subscription -->
        <div class="lg:col-span-2">
          <NuxtLink to="/home" class="mb-10 inline-block">
            <img src="/images/logo.svg" alt="Habitline Logo" class="h-11" />
          </NuxtLink>

          <div class="lg:max-w-md">
            <h2 class="mb-2.5 text-xl font-medium md:text-2xl">Stay on top of your habits</h2>
            <p class="text-default-500 mb-5 text-lg">
              No spam. Just simple advice for staying consistent.
            </p>

            <!-- Subscription Form -->
            <form class="flex flex-col items-start gap-4 lg:flex-row lg:items-center">
              <input
                type="email"
                placeholder="Enter your email"
                required
                class="border-default-200 bg-default-200 text-default-900 placeholder:text-default-400 rounded-full border px-5 py-3 text-base transition-all focus:outline-none lg:w-lg!"
              />
              <button
                type="submit"
                class="bg-default-900 w-full rounded-full px-8 py-3.5 font-medium whitespace-nowrap text-white transition-all hover:scale-95 md:w-auto"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <!-- Right Section: Links -->
        <div>
          <h3 class="text-default-900 mb-5 text-base font-medium lg:mb-7.5">Pages links</h3>
          <div class="flex flex-col justify-end gap-2">
            <NuxtLink
              to="/home"
              class="mmd:text-lg text-default-600 hover:text-default-900 text-base decoration-2 underline-offset-4 transition-colors hover:underline"
              >Home</NuxtLink
            >
            <NuxtLink
              to="/about"
              class="text-default-600 hover:text-default-900 text-base decoration-2 underline-offset-4 transition-colors hover:underline md:text-lg"
              >About</NuxtLink
            >
            <NuxtLink
              to="/pricing"
              class="text-default-600 hover:text-default-900 text-base decoration-2 underline-offset-4 transition-colors hover:underline md:text-lg"
              >Pricing</NuxtLink
            >
            <NuxtLink
              to="/contact"
              class="text-default-600 hover:text-default-900 text-base decoration-2 underline-offset-4 transition-colors hover:underline md:text-lg"
              >Contact</NuxtLink
            >
            <NuxtLink
              to="/waitlist"
              class="text-default-600 hover:text-default-900 text-base decoration-2 underline-offset-4 transition-colors hover:underline md:text-lg"
              >Waitlist</NuxtLink
            >
          </div>
        </div>
        <div class="flex flex-col gap-2">
          <h3 class="text-default-900 mb-5 text-base font-medium lg:mb-7.5">Other links</h3>
          <NuxtLink
            to="/download"
            class=":text-lg text-default-600 hover:text-default-900 text-base decoration-2 underline-offset-4 transition-colors hover:underline"
            >Download</NuxtLink
          >
          <NuxtLink
            to="/faqs"
            class="text-default-600 hover:text-default-900 text-base decoration-2 underline-offset-4 transition-colors hover:underline md:text-lg"
            >FAQs</NuxtLink
          >
          <NuxtLink
            to="/privacy-policy"
            class="text-default-600 hover:text-default-900 text-base decoration-2 underline-offset-4 transition-colors hover:underline md:text-lg"
            >Privacy Policy</NuxtLink
          >
        </div>
      </div>

      <!-- Bottom Bar -->
      <div
        class="border-default-200 mt-6 flex flex-col items-center justify-start gap-5 border-t pt-5 md:mt-8 md:flex-row md:justify-between md:gap-6 md:pt-7.5 lg:mt-16"
      >
        <p class="text-default-600 text-base md:text-lg">
          Develop by
          <a href="https://unifato.com/" class="text-default-900 font-medium hover:underline"
            >Unifato</a
          >
        </p>

        <!-- Social Icons -->
        <div class="flex items-center justify-start gap-2.5 md:justify-end">
          <a
            href="#"
            target="_blank"
            class="group bg-default-200 inline-flex size-9 items-center justify-center overflow-hidden rounded-full"
          >
            <div class="relative size-4 overflow-hidden">
              <!-- Default Icon -->
              <Icon
                icon="tabler:brand-instagram"
                class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
              />
              <Icon
                icon="tabler:brand-instagram"
                class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
              />
            </div>
          </a>
          <a
            href="#"
            target="_blank"
            class="group bg-default-200 inline-flex size-9 items-center justify-center overflow-hidden rounded-full"
          >
            <div class="relative size-4 overflow-hidden">
              <!-- Default Icon -->
              <Icon
                icon="tabler:brand-x-filled"
                class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
              />
              <Icon
                icon="tabler:brand-x-filled"
                class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
              />
            </div>
          </a>
          <a
            href="#"
            target="_blank"
            class="group bg-default-200 inline-flex size-9 items-center justify-center overflow-hidden rounded-full"
          >
            <div class="relative size-4 overflow-hidden">
              <!-- Default Icon -->
              <Icon
                icon="tabler:brand-linkedin-filled"
                class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
              />
              <Icon
                icon="tabler:brand-linkedin-filled"
                class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
              />
            </div>
          </a>
          <a
            href="#"
            target="_blank"
            class="group bg-default-200 inline-flex size-9 items-center justify-center overflow-hidden rounded-full"
          >
            <div class="relative size-4 overflow-hidden">
              <!-- Default Icon -->
              <Icon
                icon="tabler:brand-facebook-filled"
                class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
              />
              <Icon
                icon="tabler:brand-facebook-filled"
                class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
              />
            </div>
          </a>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'
</script>
