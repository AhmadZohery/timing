<template>
  <!-- Navbar -->
  <header>
    <div
      class="nav-sticky navbar fixed inset-x-0 top-0 z-120 w-full"
      :class="{ 'nav-sticky-on': isSticky }"
    >
      <div class="container py-3.5 md:py-5 lg:py-7.5">
        <div
          class="flex w-full items-center justify-between rounded-lg bg-white md:rounded-2xl lg:justify-center lg:bg-transparent"
        >
          <div
            class="flex min-w-[175px] rounded-[20px] bg-white px-3 py-1.5 md:py-4 lg:p-4 lg:shadow-lg"
          >
            <NuxtLink to="/home">
              <img src="/images/logo.svg" alt="" class="h-7.5 md:h-8" />
            </NuxtLink>
          </div>

          <div
            class="hidden h-2.5 w-full transition-all duration-500 ease-in-out in-[.nav-sticky-on]:w-2.5 lg:flex"
          ></div>

          <div class="flex items-center justify-between">
            <div
              class="hidden rounded-[20px] bg-white p-1.5 whitespace-nowrap lg:block lg:shadow-lg"
            >
              <ul id="navbar" class="flex items-center">
                <li :class="{ active: activeSection === 'features' }">
                  <NuxtLink
                    to="/home#features"
                    class="hover:bg-default-200 hover:text-default-800 flex items-center justify-center rounded-2xl px-7 py-4 text-sm font-medium transition-all"
                    >Features</NuxtLink
                  >
                </li>
                <li :class="{ active: activeSection === 'usecase' }">
                  <NuxtLink
                    to="/home#usecase"
                    class="hover:bg-default-200 hover:text-default-800 flex items-center justify-center rounded-2xl px-7 py-4 text-sm font-medium transition-all"
                    >Usecase</NuxtLink
                  >
                </li>
                <li :class="{ active: activeSection === 'metrics' }">
                  <NuxtLink
                    to="/home#metrics"
                    class="hover:bg-default-200 hover:text-default-800 flex items-center justify-center rounded-2xl px-7 py-4 text-sm font-medium transition-all"
                    >Metrics</NuxtLink
                  >
                </li>
                <li :class="{ active: activeSection === 'smart-assist' }">
                  <NuxtLink
                    to="/home#smart-assist"
                    class="hover:bg-default-200 hover:text-default-800 flex items-center justify-center rounded-2xl px-7 py-4 text-sm font-medium transition-all"
                    >Smart Assist</NuxtLink
                  >
                </li>

                <!-- Dropdown -->
                <li class="hs-dropdown relative inline-flex [--trigger:hover]">
                  <button
                    id="hs-dropdown-hover-event"
                    type="button"
                    class="hs-dropdown-toggle hover:bg-default-200 hover:text-default-800 flex items-center justify-center gap-1 rounded-2xl px-7 py-4 text-sm transition-all focus:outline-hidden disabled:pointer-events-none disabled:opacity-50"
                    aria-haspopup="menu"
                    aria-expanded="false"
                    aria-label="Dropdown"
                  >
                    Pages
                    <Icon icon="lucide:chevron-down" class="size-4" />
                  </button>

                  <div
                    class="hs-dropdown-menu duration hs-dropdown-open:opacity-100 mt-2 hidden min-w-44 rounded-xl bg-white opacity-0 transition-[opacity,margin] before:absolute before:inset-s-0 before:-top-4 before:h-4 before:w-full after:absolute after:inset-s-0 after:-bottom-4 after:h-4 after:w-full"
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="hs-dropdown-hover-event"
                  >
                    <div class="space-y-0.5 p-2.5">
                      <NuxtLink
                        to="/home"
                        class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden"
                        :class="
                          isActive('/home') ? 'text-default-800 bg-default-200' : 'text-default-600'
                        "
                      >
                        Home
                      </NuxtLink>
                      <NuxtLink
                        to="/about"
                        class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden"
                        :class="
                          isActive('/about')
                            ? 'text-default-800 bg-default-200'
                            : 'text-default-600'
                        "
                      >
                        About
                      </NuxtLink>
                      <NuxtLink
                        to="/pricing"
                        class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden"
                        :class="
                          isActive('/pricing')
                            ? 'text-default-800 bg-default-200'
                            : 'text-default-600'
                        "
                      >
                        Pricing
                      </NuxtLink>
                      <NuxtLink
                        to="/contact"
                        class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden"
                        :class="
                          isActive('/contact')
                            ? 'text-default-800 bg-default-200'
                            : 'text-default-600'
                        "
                      >
                        Contact
                      </NuxtLink>
                      <NuxtLink
                        to="/waitlist"
                        class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden"
                        :class="
                          isActive('/waitlist')
                            ? 'text-default-800 bg-default-200'
                            : 'text-default-600'
                        "
                      >
                        Waitlist
                      </NuxtLink>
                      <NuxtLink
                        to="/download"
                        class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden"
                        :class="
                          isActive('/download')
                            ? 'text-default-800 bg-default-200'
                            : 'text-default-600'
                        "
                      >
                        Download
                      </NuxtLink>
                      <NuxtLink
                        to="/faqs"
                        class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden"
                        :class="
                          isActive('/faqs') ? 'text-default-800 bg-default-200' : 'text-default-600'
                        "
                      >
                        FAQs
                      </NuxtLink>
                      <NuxtLink
                        to="/privacy-policy"
                        class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden"
                        :class="
                          isActive('/privacy-policy')
                            ? 'text-default-800 bg-default-200'
                            : 'text-default-600'
                        "
                      >
                        Privacy Policy
                      </NuxtLink>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div
            class="hidden h-2.5 w-full transition-all duration-500 ease-in-out in-[.nav-sticky-on]:w-2.5 lg:flex"
          ></div>

          <div
            class="flex items-center gap-1.25 rounded-[20px] bg-white p-1.5 shadow-lg lg:shadow-lg"
          >
            <a
              href="https://www.apple.com/in/app-store/"
              target="_blank"
              aria-label="App Store"
              class="bg-default-200 group relative flex size-8.75 items-center justify-center overflow-hidden rounded-lg transition-all duration-300 md:h-12.5 md:w-12.5 md:rounded-2xl"
            >
              <div class="relative flex items-center justify-center overflow-hidden">
                <!-- Default Icon -->
                <img
                  src="/images/icons/app-store.svg"
                  alt="Icon"
                  class="size-4.5 transition-transform duration-300 group-hover:-translate-y-6 md:size-6"
                />

                <!-- Hover Icon -->
                <img
                  src="/images/icons/app-store.svg"
                  alt="Icon"
                  class="absolute size-4.5 translate-y-6 transition-transform duration-300 group-hover:translate-y-0 md:size-6"
                />
              </div>
            </a>

            <a
              href="https://play.google.com/store/games?device=windows"
              target="_blank"
              aria-label="App Store"
              class="bg-default-200 group relative flex size-8.75 items-center justify-center overflow-hidden rounded-lg transition-all duration-300 md:h-12.5 md:w-12.5 md:rounded-2xl"
            >
              <div class="relative flex items-center justify-center overflow-hidden">
                <!-- Default Icon -->
                <img
                  src="/images/icons/play-store.svg"
                  alt="Icon"
                  class="size-4.5 transition-transform duration-300 group-hover:-translate-y-6 md:size-6"
                />

                <!-- Hover Icon -->
                <img
                  src="/images/icons/play-store.svg"
                  alt="Icon"
                  class="absolute size-4.5 translate-y-6 transition-transform duration-300 group-hover:translate-y-0 md:size-6"
                />
              </div>
            </a>

            <div class="flex items-center lg:hidden">
              <button
                type="button"
                aria-haspopup="dialog"
                aria-expanded="false"
                aria-controls="mobile-menu"
                data-hs-overlay="#mobile-menu"
                class="bg-default-200 flex size-8.75 items-center justify-center overflow-hidden rounded-lg transition-all duration-300 md:h-12.5 md:w-12.5 md:rounded-2xl"
              >
                <Icon icon="tabler:align-right" class="size-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div
      id="mobile-menu"
      class="hs-overlay hs-overlay-open:translate-y-0 md:hs-overlay-open:top-24 hs-overlay-open:top-18 hs-overlay-open:opacity-100 fixed inset-x-0 top-0 z-110 mx-4 hidden h-50 -translate-y-full transform overflow-hidden rounded-lg bg-white opacity-0 shadow-xl transition-all duration-300 [--body-scroll:true] md:mx-5"
      role="dialog"
      tabindex="-1"
      aria-labelledby="mobile-menu-label"
    >
      <div class="flex max-h-50 flex-col overflow-y-auto p-3">
        <NuxtLink
          to="/home#features"
          class="group text-default-600 hover:text-primary flex items-center p-1.5 text-base font-medium transition-all"
        >
          Features
        </NuxtLink>

        <NuxtLink
          to="/home#usecase"
          class="group text-default-600 hover:text-primary flex items-center p-1.5 text-base font-medium transition-all"
        >
          Usecase
        </NuxtLink>

        <NuxtLink
          to="/home#metrics"
          class="group text-default-600 hover:text-primary flex items-center p-1.5 text-base font-medium transition-all"
        >
          Metrics
        </NuxtLink>

        <NuxtLink
          to="/home#smart-assist"
          class="group text-default-600 hover:text-primary flex items-center p-1.5 text-base font-medium transition-all"
        >
          Smart Assist
        </NuxtLink>

        <div class="hs-accordion">
          <button
            type="button"
            class="hs-accordion-toggle group text-default-600 hover:text-primary flex items-center p-1.5 text-base font-medium transition-all"
            aria-haspopup="menu"
            aria-expanded="false"
            aria-label="Dropdown"
          >
            Pages
            <Icon icon="tabler:chevron-down" class="ms-4" />
          </button>

          <div
            class="hs-accordion-content hidden w-full overflow-hidden ps-5 pb-4 transition-[height]"
          >
            <NuxtLink
              to="/home"
              class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-base focus:outline-hidden"
              :class="isActive('/home') ? 'text-default-800 bg-default-200' : 'text-default-600'"
            >
              Home
            </NuxtLink>
            <NuxtLink
              to="/about"
              class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-base focus:outline-hidden"
              :class="isActive('/about') ? 'text-default-800 bg-default-200' : 'text-default-600'"
            >
              About
            </NuxtLink>
            <NuxtLink
              to="/pricing"
              class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-base focus:outline-hidden"
              :class="isActive('/pricing') ? 'text-default-800 bg-default-200' : 'text-default-600'"
            >
              Pricing
            </NuxtLink>
            <NuxtLink
              to="/contact"
              class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-base focus:outline-hidden"
              :class="isActive('/contact') ? 'text-default-800 bg-default-200' : 'text-default-600'"
            >
              Contact
            </NuxtLink>
            <NuxtLink
              to="/waitlist"
              class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-base focus:outline-hidden"
              :class="
                isActive('/waitlist') ? 'text-default-800 bg-default-200' : 'text-default-600'
              "
            >
              Waitlist
            </NuxtLink>
            <NuxtLink
              to="/download"
              class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-base focus:outline-hidden"
              :class="
                isActive('/download') ? 'text-default-800 bg-default-200' : 'text-default-600'
              "
            >
              Download
            </NuxtLink>
            <NuxtLink
              to="/faqs"
              class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-base focus:outline-hidden"
              :class="isActive('/faqs') ? 'text-default-800 bg-default-200' : 'text-default-600'"
            >
              FAQs
            </NuxtLink>
            <NuxtLink
              to="/privacy-policy"
              class="hover:text-default-800 hover:bg-default-200 flex items-center gap-x-3.5 rounded-lg px-2.5 py-1.5 text-base focus:outline-hidden"
              :class="
                isActive('/privacy-policy') ? 'text-default-800 bg-default-200' : 'text-default-600'
              "
            >
              Privacy Policy
            </NuxtLink>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue'
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'
import { useRoute } from '#app'

const route = useRoute()
const isSticky = ref(false)
const activeSection = ref('')

const isActive = (path: string) => {
  if (path === '/home') {
    return route.path === '/home' || route.path === '/'
  }
  return route.path === path
}

const handleScroll = () => {
  isSticky.value = window.scrollY >= 50
  const sections = ['features', 'usecase', 'metrics', 'smart-assist']
  let currentSection = ''
  if (route.path === '/home' || route.path === '/') {
    for (const sectionId of sections) {
      const el = document.getElementById(sectionId)
      if (el) {
        const rect = el.getBoundingClientRect()
        if (rect.top <= 150) {
          currentSection = sectionId
        }
      }
    }
  }
  activeSection.value = currentSection
}

onMounted(() => {
  window.addEventListener('scroll', handleScroll)
  handleScroll()
})

onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll)
})

watch(
  () => route.fullPath,
  () => {
    if (typeof window !== 'undefined' && (window as any).HSOverlay) {
      ;(window as any).HSOverlay.close('#mobile-menu')
    }
    setTimeout(handleScroll, 100)
  },
)
</script>
