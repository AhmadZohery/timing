<template>
  <Hero />
  <Mission />
  <Purpose />
  <Stats />
  <Team />
  <Download />
</template>

<script setup lang="ts">
import Hero from './components/Hero.vue'
import Mission from './components/Mission.vue'
import Purpose from './components/Purpose.vue'
import Stats from './components/Stats.vue'
import Team from './components/Team.vue'
import Download from './components/Download.vue'
import { usePageTitle } from '~/composables/usePageTitle'

usePageTitle('About')
</script>
