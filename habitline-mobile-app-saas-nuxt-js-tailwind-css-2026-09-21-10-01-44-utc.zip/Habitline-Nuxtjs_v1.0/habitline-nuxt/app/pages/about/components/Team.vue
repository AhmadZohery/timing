<template>
  <section class="relative overflow-hidden">
    <div class="container">
      <div
        class="rounded-3xl bg-white p-7.5 lg:p-25"
        style="
          background-image: radial-gradient(#e5e7eb 1.5px, transparent 1.5px);
          background-size: 24px 24px;
        "
      >
        <div class="absolute inset-0 opacity-20"></div>
        <div class="relative z-10">
          <div class="mb-8 space-y-4 text-center md:mb-12 lg:mb-16">
            <span
              class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1 text-sm font-medium md:py-1.5"
              >Our Team</span
            >
            <h2 class="text-default-900 text-2xl font-medium md:text-4xl lg:text-[50px]">
              The people who
              <br class="hidden md:block" />
              drive the work
            </h2>
          </div>

          <div class="mx-auto grid grid-cols-2 gap-5 md:grid-cols-3 lg:max-w-6xl lg:gap-12.5">
            <div v-for="member in teamData" :key="member.name" class="group mx-auto text-center">
              <div class="relative mx-auto overflow-hidden">
                <img
                  :src="member.image"
                  :alt="member.name"
                  :class="[
                    'mb-2.5 size-38 rounded-2xl object-cover md:size-52.5 lg:mb-5 lg:size-37.5',
                    member.imageClass,
                  ]"
                />
                <div
                  :class="[
                    'absolute inset-0 size-37.5 rounded-2xl bg-black/40 opacity-0 transition-opacity duration-500 group-hover:opacity-100',
                    member.wrapperClass,
                  ]"
                >
                  <a
                    :href="member.twitter"
                    target="_blank"
                    class="absolute inset-s-1/2 bottom-5 flex size-9 -translate-1/2 translate-y-12 items-center justify-center rounded-full bg-white transition-transform duration-500 group-hover:translate-y-0"
                  >
                    <Icon icon="tabler:brand-x-filled" class="text-default-800 size-4" />
                  </a>
                </div>
              </div>
              <div class="text-center">
                <h3 :class="['font-bold md:text-xl', member.nameClass]">{{ member.name }}</h3>
                <p class="text-default-500 text-sm md:text-lg">{{ member.role }}</p>
              </div>
            </div>
          </div>

          <div class="mx-auto mt-10 max-w-md space-y-5 text-center md:mt-12 lg:mt-19">
            <h3 class="text-default-900 text-xl leading-snug font-medium md:text-2xl">
              Be part of shaping systems that keep teams aligned and productive.
            </h3>
            <NuxtLink
              to="/contact"
              class="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-black px-3.5 text-white shadow-xl! transition-all duration-300 hover:scale-95 md:px-8.5"
            >
              <div
                class="relative inline-flex flex-col items-center text-nowrap transition-transform duration-300 group-hover:-translate-y-full"
              >
                <div class="flex h-10.5 items-center gap-3 md:h-14">
                  <span class="font-medium">Contact us</span>
                </div>
                <div class="absolute top-full flex h-10.5 items-center gap-3 md:h-14">
                  <span class="font-medium">Contact us</span>
                </div>
              </div>
            </NuxtLink>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'

type TeamMemberType = {
  name: string
  role: string
  image: string
  twitter: string
  nameClass: string
  wrapperClass: string
  imageClass: string
}

const teamData: TeamMemberType[] = [
  {
    name: 'Riya Patel',
    role: 'Lead Designer',
    image: '/images/team/team-image-01.webp',
    twitter: 'https://x.com',
    nameClass: 'text-default-900 mb-2',
    wrapperClass: '',
    imageClass: '',
  },
  {
    name: 'Ethan Walker',
    role: 'Creative Director',
    image:
      'https://cdn.prod.website-files.com/692fd4f000a6f446ca91cb33/693bfbeaa0a9ea44852138b3_team-image-02.webp',
    twitter: 'https://x.com',
    nameClass: 'text-gray-900',
    wrapperClass: 'flex items-center justify-center',
    imageClass: '',
  },
  {
    name: 'Logan Reed',
    role: 'Frontend Engineer',
    image:
      'https://cdn.prod.website-files.com/692fd4f000a6f446ca91cb33/693bfbeb774ae48530ed4c5e_team-image-03.webp',
    twitter: 'https://x.com',
    nameClass: 'text-gray-900',
    wrapperClass: 'flex items-center justify-center',
    imageClass: '',
  },
  {
    name: 'Harper Collins',
    role: 'Content & Brand Specialist',
    image:
      'https://cdn.prod.website-files.com/692fd4f000a6f446ca91cb33/693bfbeb2350fda6bb729017_team-image-04.webp',
    twitter: 'https://x.com',
    nameClass: 'text-gray-900',
    wrapperClass: 'flex items-center justify-center mx-auto',
    imageClass: 'mx-auto',
  },
  {
    name: 'Noah Brooks',
    role: 'Project Lead',
    image:
      'https://cdn.prod.website-files.com/692fd4f000a6f446ca91cb33/693bfbec7839cc0d1b9aed75_team-image-05.webp',
    twitter: 'https://x.com',
    nameClass: 'text-gray-900',
    wrapperClass: 'flex items-center justify-center',
    imageClass: '',
  },
  {
    name: 'Sophie Carter',
    role: 'Product Strategist',
    image:
      'https://cdn.prod.website-files.com/692fd4f000a6f446ca91cb33/693bfbedfb99dbe8b71eca8e_team-image-06.webp',
    twitter: 'https://x.com',
    nameClass: 'text-gray-900',
    wrapperClass: 'flex items-center justify-center',
    imageClass: '',
  },
]
</script>
