<template>
  <section class="relative overflow-hidden pt-34 pb-15 md:pt-40 md:pb-25 lg:py-50">
    <div class="pointer-events-none absolute inset-0 z-0 opacity-60">
      <img
        src="/images/locations/cloud-04.webp"
        alt=""
        class="absolute top-10 left-[-5%] w-1/3 blur-sm"
      />
      <img src="/images/locations/cloud-01.webp" alt="" class="absolute bottom-20 left-0 w-1/4" />
      <img
        src="/images/locations/cloud-04.webp"
        alt=""
        class="absolute right-0 bottom-[-10%] w-full opacity-40"
      />
    </div>

    <div class="relative z-10 container mx-auto mb-15 lg:mb-32">
      <div class="mb-8 max-w-md lg:mb-20 lg:max-w-xl">
        <span
          class="border-default-200 text-default-800 mb-2 inline-block rounded-full border bg-white px-5 py-1 text-sm font-medium md:py-1.5 lg:mb-0"
          >About the App</span
        >
        <h1
          class="text-default-900 text-4xl font-medium tracking-tight md:text-[50px] lg:text-[90px]"
        >
          A simpler way to build habits
        </h1>
        <div
          class="mt-2.5 flex flex-col items-start gap-5 md:mt-5 lg:mt-12 lg:flex-row lg:items-center lg:gap-7.5"
        >
          <NuxtLink
            to="/download"
            class="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-black px-3.5 text-white shadow-xl! transition-all duration-300 hover:scale-95 lg:px-8.5"
          >
            <div
              class="relative inline-flex flex-col items-center text-nowrap transition-transform duration-300 group-hover:-translate-y-full"
            >
              <div class="flex h-10.5 items-center gap-3 lg:h-14">
                <span class="text-sm font-medium lg:text-base">Download the app</span>
              </div>
              <div class="absolute top-full flex h-10.5 items-center gap-3 lg:h-14">
                <span class="text-sm font-medium lg:text-base">Download the app</span>
              </div>
            </div>
          </NuxtLink>

          <div class="flex items-center gap-6">
            <div class="flex -space-x-2.5">
              <img
                class="border-default-800 size-10 rounded-full border-2 object-cover shadow-sm"
                src="/images/team/avatar-01.webp"
                alt=""
              />
              <img
                class="border-default-800 size-10 rounded-full border-2 object-cover shadow-sm"
                src="/images/team/avatar-02.webp"
                alt=""
              />
              <img
                class="border-default-800 size-10 rounded-full border-2 object-cover shadow-sm"
                src="/images/team/avatar-03.webp"
                alt=""
              />
              <div
                class="border-default-800 bg-default-50 text-default-800 inline-flex size-10 items-center justify-center rounded-full border-2 text-[8px] font-bold shadow-sm"
              >
                You?
              </div>
            </div>
            <div class="flex flex-col">
              <div class="flex gap-1.5">
                <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
                <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
                <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
                <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
                <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
              </div>
              <p class="text-default-600 text-lg font-medium text-nowrap">Trusted by worldwide</p>
            </div>
          </div>
        </div>
      </div>

      <div class="relative">
        <div class="grid grid-cols-1 items-end gap-5 md:grid-cols-12 lg:gap-7.5">
          <div class="md:col-span-7">
            <div class="overflow-hidden rounded-2xl lg:rounded-3xl">
              <img
                src="/images/about/about-image.webp"
                alt="Community"
                class="h-60 w-full object-cover lg:h-105"
              />
            </div>
          </div>
          <div class="md:col-span-5">
            <div
              class="relative flex h-86 items-end justify-center overflow-visible rounded-4xl bg-gradient-to-b from-sky-500 to-cyan-100 md:h-60 lg:h-105"
            >
              <img
                src="/images/about/about-image-01.webp"
                alt=""
                class="absolute inset-0 h-full w-full rounded-2xl object-cover lg:rounded-3xl"
              />
              <div class="absolute bottom-2 z-20 lg:-top-[370px] lg:bottom-4">
                <img
                  src="/images/event/phone-image.png"
                  alt="Phone"
                  class="h-80 rounded-2xl drop-shadow-[0_40px_60px_rgba(0,0,0,0.25)] md:h-140 md:w-68 lg:h-175 lg:w-85"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="text-center">
        <span class="text-default-800 mb-5 block text-base lg:mb-7.5 lg:text-xl"
          >Trusted worldwide</span
        >
      </div>
      <div class="relative overflow-hidden">
        <div
          class="from-body-bg pointer-events-none absolute top-0 left-0 z-10 h-full w-32 bg-gradient-to-r to-transparent"
        ></div>
        <div
          class="from-body-bg pointer-events-none absolute top-0 right-0 z-10 h-full w-32 bg-gradient-to-l to-transparent"
        ></div>
        <div class="animate-marquee flex gap-12.5 lg:gap-16">
          <div v-for="n in 2" :key="n" class="flex items-center gap-12.5 lg:gap-16">
            <img
              v-for="(client, clientIdx) in clientsData"
              :key="clientIdx"
              :src="client.img"
              :alt="client.alt"
              class="h-6 w-auto object-contain"
            />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'

type ClientType = {
  img: string
  alt: string
}

const clientsData: ClientType[] = [
  { img: '/images/client/client-01.svg', alt: 'Client Logo' },
  { img: '/images/client/client-02.svg', alt: 'Client Logo' },
  { img: '/images/client/client-03.svg', alt: 'Client Logo' },
  { img: '/images/client/client-04.svg', alt: 'Client Logo' },
  { img: '/images/client/client-05.svg', alt: 'Client Logo' },
  { img: '/images/client/client-06.svg', alt: 'Client Logo' },
]
</script>
