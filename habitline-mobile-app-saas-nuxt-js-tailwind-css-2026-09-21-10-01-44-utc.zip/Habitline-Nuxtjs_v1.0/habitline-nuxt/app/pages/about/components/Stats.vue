<template>
  <section class="pb-20 md:pb-25 lg:pb-50">
    <div class="container">
      <div class="grid grid-cols-1 items-center gap-7.5 lg:grid-cols-2 lg:gap-12">
        <div class="flex flex-col gap-y-5 lg:gap-y-12.5">
          <div class="space-y-4">
            <span
              class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1 text-sm font-medium md:py-1.5"
              >Habitline in numbers</span
            >
            <h2
              class="text-default-900 text-3xl leading-tight font-medium tracking-tight md:text-4xl lg:text-[50px]"
            >
              Real habits, real
              <br class="hidden lg:block" />
              consistency
            </h2>
          </div>

          <div class="grid grid-cols-2 gap-7.5 lg:grid-cols-1 lg:gap-10">
            <div class="items-center gap-5 lg:flex lg:gap-7.5">
              <div class="mb-2 min-w-25 text-center lg:mb-0 lg:text-start">
                <span class="text-primary-8 text-2xl font-bold lg:text-4xl">87</span>
                <span class="text-primary-8 text-2xl font-bold lg:text-4xl"> %</span>
              </div>
              <div class="bg-default-300 hidden h-16 w-px lg:block"></div>
              <div class="text-center md:text-start">
                <p class="text-default-900 mb-1.5 font-medium md:text-lg">
                  Average monthly consistency
                </p>
                <p class="text-default-500 text-sm">Users stay on track most of the month.</p>
              </div>
            </div>

            <div class="items-center gap-7.5 lg:flex">
              <div class="mb-2 min-w-25 text-center lg:mb-0 lg:text-start">
                <span class="text-primary-1 text-2xl font-bold lg:text-4xl">87</span>
              </div>
              <div class="bg-default-300 hidden h-16 w-px lg:block"></div>
              <div class="text-center md:text-start">
                <p class="text-default-900 mb-1.5 font-medium md:text-lg">
                  Sessions completed on average
                </p>
                <p class="text-default-500 text-sm">Regular habits are completed each month.</p>
              </div>
            </div>

            <div class="col-span-2 items-center gap-7.5 md:col-span-1 lg:flex">
              <div class="mb-2 min-w-25 text-center lg:mb-0 lg:text-start">
                <span class="text-primary text-2xl font-bold text-nowrap lg:text-4xl">32 +</span>
              </div>
              <div class="bg-default-300 hidden h-16 w-px lg:block"></div>
              <div class="text-center md:text-start">
                <p class="text-default-900 mb-1.5 font-medium md:text-lg">
                  Countries with active Habitline users
                </p>
                <p class="text-default-500 text-sm">People are using Habitline around the world.</p>
              </div>
            </div>
          </div>
        </div>

        <div
          class="bg-default-200 relative flex flex-col items-center justify-between overflow-hidden rounded-2xl md:min-h-125 lg:min-h-150"
        >
          <div class="z-10 pt-12.5 pb-12.5 text-center lg:pb-8">
            <h3
              class="text-primary-1 mb-3.75 text-4xl font-bold drop-shadow-[0_10px_15px_rgba(249,115,22,0.3)] md:text-5xl lg:text-[90px]"
            >
              62,000+
            </h3>
            <span
              class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1 text-sm font-medium md:py-1.5"
              >check-ins logged last month</span
            >
          </div>

          <div class="relative flex h-full w-full items-end">
            <img src="/images/locations/glob-image.png" alt="Globe" class="w-full object-cover" />
            <img
              src="/images/locations/cloud-01.webp"
              class="absolute inset-e-0 -bottom-58 -left-50 z-20 w-full"
              alt="Clouds"
            />
            <img
              src="/images/locations/cloud-05.webp"
              class="absolute -right-60 -bottom-45 z-20 w-full"
              alt="Clouds"
            />
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts"></script>
