<template>
  <section class="py-20 md:py-25 lg:py-50">
    <div class="container">
      <div class="grid items-center gap-7.5 md:grid-cols-2 lg:gap-15">
        <div class="relative">
          <div class="relative overflow-hidden rounded-3xl">
            <img
              src="/images/about/about-image-02.webp"
              alt=""
              class="h-100 w-full object-cover md:h-125"
            />
            <div class="absolute inset-0 bg-black/15"></div>
            <div
              class="absolute inset-s-4 top-20 flex flex-col gap-y-1 md:top-36 lg:inset-s-10.5 lg:top-24 lg:gap-y-4"
            >
              <img src="/images/workspace/dashboard-06.svg" alt="" class="w-46 md:w-58" />
              <img src="/images/workspace/dashboard-05.svg" alt="" class="w-46 md:w-58" />
              <img src="/images/workspace/dashboard-04.svg" alt="" class="w-46 md:w-58" />
              <img src="/images/icons/icon-30.svg" alt="" class="mx-auto size-18.75" />
            </div>
            <img
              src="/images/workspace/dashboard-01.svg"
              alt=""
              class="absolute inset-e-4 top-4 h-20 md:h-28 lg:inset-e-15 lg:top-11.5 lg:h-37"
            />
          </div>
        </div>

        <div class="space-y-3.5 lg:space-y-5">
          <span
            class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1 text-sm font-medium md:py-1.5"
            >Why Habitline Exists</span
          >
          <h2
            class="text-default-900 mb-3.5 text-2xl leading-tight font-medium tracking-tight md:text-4xl lg:text-[50px]"
          >
            Building habits shouldn’t feel overwhelming
          </h2>
          <p class="text-default-600 mb-3.75 leading-tight md:mb-6 lg:w-md lg:text-lg">
            Most tools expect perfect streaks, fixed schedules, and unlimited motivation. But real
            life isn’t that consistent. Days get busy. Plans shift. People forget.
          </p>
          <div class="mb-5 space-y-2 lg:mb-12.5">
            <div class="flex items-center gap-2.5">
              <div>
                <Icon icon="lucide:circle-check" class="text-primary-2 mt-1" />
              </div>
              <p class="text-default-800 text-lg font-medium">Real life is unpredictable</p>
            </div>
            <div class="flex items-center gap-2.5">
              <div>
                <Icon icon="lucide:circle-check" class="text-primary-2 mt-1" />
              </div>
              <p class="text-default-800 text-lg font-medium">
                Progress shouldn’t feel overwhelming
              </p>
            </div>
            <div class="flex items-center gap-2.5">
              <div>
                <Icon icon="lucide:circle-check" class="text-primary-2 mt-1" />
              </div>
              <p class="text-default-800 text-lg font-medium">Motivation isn’t enough</p>
            </div>
          </div>
          <NuxtLink
            to="/features"
            class="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-black px-3.5 text-white shadow-xl! transition-all duration-300 hover:scale-95 md:px-8.5"
          >
            <div
              class="relative inline-flex flex-col items-center text-nowrap transition-transform duration-300 group-hover:-translate-y-full"
            >
              <div class="flex h-10.5 items-center gap-3 md:h-14">
                <span class="text-sm font-medium md:text-base">Open the features</span>
              </div>
              <div class="absolute top-full flex h-10.5 items-center gap-3 md:h-14">
                <span class="text-sm font-medium md:text-base">Open the features</span>
              </div>
            </div>
          </NuxtLink>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'
</script>
