<template>
  <section class="pt-32 pb-6 md:pt-40 md:pb-16 lg:pt-50">
    <div class="container">
      <div class="mx-auto text-center md:w-2xl">
        <h1
          class="text-default-900 mb-2.5 text-4xl font-medium tracking-tight md:text-5xl lg:text-[90px]"
        >
          Join the Habitline waitlist
        </h1>
        <p class="mx-auto mb-5 text-base md:mb-7.5 md:text-xl">
          We’re getting ready to launch a cleaner, calmer habit app built around real life.
        </p>
      </div>

      <div class="mx-auto md:w-2xl lg:w-lg">
        <form
          class="flex flex-col items-start justify-center gap-2.5 md:flex-row md:gap-4 lg:items-center"
        >
          <input
            type="email"
            placeholder="Enter your email"
            required
            class="border-default-200 bg-default-200 text-default-900 placeholder:text-default-400 w-full rounded-full border px-5 py-3 text-base transition-all focus:outline-none md:w-lg!"
          />
          <div class="mx-auto">
            <button
              type="submit"
              class="bg-default-900 w-auto rounded-full px-8 py-3.5 text-center font-medium whitespace-nowrap text-white transition-all hover:scale-95"
            >
              Join the waitlist
            </button>
          </div>
        </form>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { usePageTitle } from '~/composables/usePageTitle'

usePageTitle('Waitlist')
</script>
