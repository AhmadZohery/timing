<template>
  <section class="py-20 md:py-25 lg:py-50">
    <div class="container">
      <div class="mb-8 text-center md:mb-12.5">
        <h3 class="text-4xl font-medium lg:text-5xl">Reach us directly</h3>
      </div>

      <div class="mx-auto grid grid-cols-1 gap-5 md:grid-cols-2 md:gap-7.5 lg:w-3xl">
        <div
          class="group flex flex-col justify-end gap-y-3.5 rounded-2xl bg-white p-3.5 text-center shadow-lg md:gap-y-10 md:p-5 md:text-start lg:gap-y-12.5 lg:p-7.5"
        >
          <div
            class="bg-primary-3 mx-auto flex size-10 items-center justify-center rounded-full md:mx-0 md:size-12.5"
          >
            <Icon icon="lucide:headset" class="text-xl text-white" />
          </div>
          <div>
            <h4 class="text-default-900 mb-2.5 text-xl font-medium md:mb-5 md:text-2xl">
              Support Email
            </h4>
            <a
              href="mailto:support@habitline.app"
              class="hover:text-default-800 decoration-2 underline-offset-4 hover:underline"
              >support@habitline.app</a
            >
          </div>
        </div>

        <div
          class="group flex flex-col justify-end gap-y-3.5 rounded-2xl bg-white p-3.5 text-center shadow-lg md:gap-y-10 md:p-5 md:text-start lg:gap-y-12.5 lg:p-7.5"
        >
          <div
            class="bg-primary-8 mx-auto flex size-10 items-center justify-center rounded-full md:mx-0 md:size-12.5"
          >
            <Icon icon="lucide:handshake" class="text-xl text-white" />
          </div>
          <div>
            <h4 class="text-default-900 mb-2.5 text-xl font-medium md:mb-5 md:text-2xl">
              Business / Partnerships
            </h4>
            <a
              href="mailto:hello@habitline.app"
              class="hover:text-default-800 decoration-2 underline-offset-4 hover:underline"
              >hello@habitline.app</a
            >
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
</script>
