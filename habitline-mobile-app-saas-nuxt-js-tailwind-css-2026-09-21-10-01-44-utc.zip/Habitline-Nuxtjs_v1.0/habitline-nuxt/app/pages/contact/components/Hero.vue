<template>
  <section class="pt-32.5 md:pt-36 lg:pt-50">
    <div class="container">
      <div class="mb-12 text-center lg:mb-20">
        <span
          class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1 text-sm font-medium md:py-1.5"
        >
          Contact Us
        </span>
        <h1
          class="text-default-900 my-2.5 text-4xl font-medium tracking-tight md:text-5xl lg:text-[90px]"
        >
          We're here to help
        </h1>
        <p class="mx-auto md:w-lg">
          If you have questions, feedback, or need support, reach out, and we’ll get back to you as
          soon as we can.
        </p>
      </div>

      <div class="overflow-hidden rounded-2xl bg-white shadow-xl md:flex">
        <div
          class="relative order-2! flex min-h-90 items-center justify-center overflow-hidden bg-[url('/images/locations/contact-image.webp')] md:order-1 md:min-h-125 md:w-6/8 lg:w-2/5"
        >
          <div class="absolute inset-0 bg-black/30"></div>
          <img
            src="/images/workspace/phone-image.png"
            loading="lazy"
            alt="Dashboard Image"
            class="relative z-10 -mb-67 w-full max-w-65 drop-shadow-2xl lg:max-w-84"
          />
        </div>

        <div class="order-1! px-5 py-7.5 md:order-2 md:p-5 lg:w-3/5 lg:p-12.5">
          <form id="contact-form" class="space-y-3.5 md:space-y-8">
            <div class="grid grid-cols-1 gap-2.5 md:grid-cols-2 lg:gap-8">
              <div class="flex flex-col">
                <label for="name" class="text-default-600 mb-2.5 text-sm font-medium"
                  >Your name*</label
                >
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Dennis Barrett"
                  required
                  class="bg-default-200/80 text-default-800 placeholder:text-default-600 w-full rounded-xl border-none px-5 py-4 transition-all focus:ring-2 focus:ring-slate-200 focus:outline-none"
                />
              </div>
              <div class="flex flex-col">
                <label for="subject" class="text-default-600 mb-2.5 text-sm font-medium"
                  >Subject</label
                >
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  placeholder="Topic of your request"
                  class="bg-default-200/80 text-default-800 placeholder:text-default-600 w-full rounded-xl border-none px-5 py-4 transition-all focus:ring-2 focus:ring-slate-200 focus:outline-none"
                />
              </div>
            </div>

            <div class="flex flex-col">
              <label for="email" class="text-default-600 mb-2.5 text-sm font-medium"
                >Email address*</label
              >
              <input
                type="email"
                id="email"
                name="email"
                placeholder="dannis@example.com"
                required
                class="bg-default-200/80 text-default-800 placeholder:text-default-600 w-full rounded-xl border-none px-5 py-4 transition-all focus:ring-2 focus:ring-slate-200 focus:outline-none"
              />
            </div>

            <div class="flex flex-col">
              <label for="message" class="text-default-600 mb-2.5 text-sm font-medium"
                >Message</label
              >
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Write your message"
                class="bg-default-200/80 text-default-800 placeholder:text-default-600 w-full resize-none rounded-xl border-none px-5 py-4 transition-all focus:ring-2 focus:ring-slate-200 focus:outline-none"
              ></textarea>
            </div>

            <div class="pt-4">
              <button
                type="submit"
                class="bg-default-900 rounded-full px-8 py-4 font-medium text-white shadow-xl transition-all hover:scale-95"
              >
                Send message
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts"></script>
