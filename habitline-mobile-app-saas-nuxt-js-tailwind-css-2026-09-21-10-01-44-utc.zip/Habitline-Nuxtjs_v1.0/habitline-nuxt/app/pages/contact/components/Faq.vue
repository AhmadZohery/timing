<template>
  <section class="md:pb-25 lg:pb-50">
    <div class="container">
      <div class="mb-8 space-y-3.5 text-center md:mb-12.5">
        <span
          class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1.5 text-sm font-medium"
        >
          Common Questions
        </span>
        <h3 class="text-2xl font-medium md:text-4xl lg:text-5xl">Frequently Asked Questions</h3>
      </div>

      <div class="hs-accordion-group mx-auto space-y-2.5 lg:w-3xl">
        <div
          v-for="(item, idx) in faqData"
          :key="item.id"
          :class="[
            'hs-accordion hs-accordion-active:shadow-md rounded-2xl border border-zinc-100 bg-white shadow-sm transition-all duration-300',
            { active: idx === 0 },
          ]"
          :id="item.id"
        >
          <button
            class="hs-accordion-toggle hs-accordion-active:text-default-950 text-default-900 inline-flex w-full items-center justify-between p-3.5 text-start font-bold transition hover:text-zinc-500 lg:p-5"
            :aria-controls="item.collapseId"
          >
            <h3 class="text-base font-medium md:text-xl">{{ item.question }}</h3>
            <div
              class="hs-accordion-active:rotate-45 bg-default-200 relative flex size-6.5 shrink-0 items-center justify-center rounded-full transition-transform duration-300 md:size-8.5"
            >
              <Icon icon="lucide:plus" class="text-default-800 size-3 md:size-5" />
            </div>
          </button>
          <div
            :id="item.collapseId"
            :class="[
              'hs-accordion-content w-full overflow-hidden transition-[height] duration-300',
              { hidden: idx !== 0 },
            ]"
            :aria-labelledby="item.id"
          >
            <div
              class="px-3.5 pb-3.5 text-base leading-normal text-zinc-500 md:text-lg md:leading-relaxed lg:px-5 lg:pb-5"
            >
              {{ item.answer }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'

type FaqType = {
  id: string
  collapseId: string
  question: string
  answer: string
}

const faqData: FaqType[] = [
  {
    id: 'hs-heading-one',
    collapseId: 'hs-collapse-one',
    question: 'How many habits can I track?',
    answer: 'You can track unlimited habits, giving you complete freedom to create and organize.',
  },
  {
    id: 'hs-heading-two',
    collapseId: 'hs-collapse-two',
    question: 'Do reminders work across all devices?',
    answer:
      'Yes. Your reminders sync automatically and trigger on any device where Habitline is installed.',
  },
  {
    id: 'hs-heading-three',
    collapseId: 'hs-collapse-three',
    question: 'What happens if I miss a day?',
    answer:
      'If you miss a day, nothing drastic happens your progress is still saved, and you can pick up right where you left off.',
  },
  {
    id: 'hs-heading-four',
    collapseId: 'hs-collapse-four',
    question: 'Can I create routines for different times of day?',
    answer:
      'Yes, you can create routines for different times of the day. Organize your habits into morning.',
  },
  {
    id: 'hs-heading-five',
    collapseId: 'hs-collapse-five',
    question: 'Is Habitline free to use?',
    answer:
      'Habitline is free to use with essential features available at no cost. You can track habits, create routines.',
  },
]
</script>
