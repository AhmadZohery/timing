<template>
  <Hero />
  <Direct />
  <Faq />
</template>

<script setup lang="ts">
import Hero from './components/Hero.vue'
import Direct from './components/Direct.vue'
import Faq from './components/Faq.vue'
import { usePageTitle } from '~/composables/usePageTitle'

usePageTitle('Contact')
</script>
