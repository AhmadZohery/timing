<template>
  <section class="relative overflow-hidden pt-32 md:pb-14 lg:pt-38">
    <!-- Decorative Background Clouds -->
    <div class="pointer-events-none absolute inset-0 z-0">
      <img
        src="/images/workspace/decoration.webp"
        class="absolute inset-s-0 top-25 bottom-20 w-1/2 blur-sm"
        alt=""
      />
      <img
        src="/images/locations/cloud-02.webp"
        class="absolute inset-e-0 bottom-0 h-74 w-1/3"
        alt=""
      />
      <img src="/images/locations/cloud-05.webp" class="absolute inset-e-10 top-10 w-1/4" alt="" />
    </div>

    <div class="relative z-10 container mx-auto px-6 lg:px-12">
      <div class="grid grid-cols-1 items-center gap-12 md:grid-cols-2">
        <!-- Left Content -->
        <div class="max-w-2xl">
          <h1
            class="text-default-900 mb-5 text-3xl font-medium tracking-tight md:text-5xl lg:text-[68px]"
          >
            Start building better habits today
          </h1>
          <p class="text-default-600 mb-5 text-base leading-tight md:mb-7.5 md:text-xl">
            Download Habitline to build routines that adjust to your day. Track habits get smart
            suggestions that help you stay consistent without pressure.
          </p>

          <!-- Stats Section -->
          <div class="mb-5 flex gap-7.5 md:mb-7.5 lg:gap-20">
            <div>
              <div class="flex items-baseline gap-1">
                <h2 class="text-default-900 text-2xl font-medium md:text-3xl lg:text-4xl">32</h2>
                <span class="text-default-900 text-2xl font-medium md:text-3xl lg:text-4xl">+</span>
              </div>
              <p class="text-default-600 mt-2 text-lg font-medium">Countries using Habitline</p>
            </div>
            <div>
              <h2 class="text-default-900 text-2xl font-medium md:text-3xl lg:text-4xl">46</h2>
              <p class="text-default-600 mt-2 text-lg font-medium">Sessions completed per user</p>
            </div>
          </div>

          <!-- App Store Buttons -->
          <div class="flex flex-wrap gap-3.5">
            <NuxtLink to="" target="_blank" class="transition-transform hover:scale-95">
              <img src="/images/icons/app-storebox.svg" alt="App Store" class="h-12.5 w-auto" />
            </NuxtLink>
            <NuxtLink to="" target="_blank" class="transition-transform hover:scale-95">
              <img src="/images/icons/google-playbox.svg" alt="Google Play" class="h-12.5 w-auto" />
            </NuxtLink>
          </div>

          <!-- QR Code Card -->
          <div
            class="mt-6.5 inline-flex items-center gap-5 rounded-2xl bg-white p-2 shadow-2xl md:mt-10 lg:mt-20"
          >
            <div class="bg-default-200 shrink-0 rounded-2xl p-4">
              <img src="/images/icons/icon-39.svg" alt="QR Code" class="size-25" />
            </div>
            <div class="relative">
              <img
                src="/images/icons/icon-66.svg"
                class="absolute top-2 left-0 size-15 rotate-[-10deg]"
                alt=""
              />
              <h3 class="text-default-900 mt-15 text-2xl leading-tight font-medium">
                Scan here <br />
                to download
              </h3>
            </div>
          </div>
        </div>

        <!-- Right Content (Phone Mockup) -->
        <div class="relative flex justify-center">
          <img
            src="/images/workspace/phone-image.png"
            alt="App Dashboard"
            class="h-175 w-full max-w-87.5 transition-transform duration-500"
          />
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { NuxtLink } from '#components'
import { usePageTitle } from '~/composables/usePageTitle'

usePageTitle('Download')
</script>
