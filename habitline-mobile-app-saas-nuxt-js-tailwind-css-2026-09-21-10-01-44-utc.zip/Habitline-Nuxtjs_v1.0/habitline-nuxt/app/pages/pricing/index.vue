<template>
  <Plans />
  <Compare />
  <Faq />
</template>

<script setup lang="ts">
import Plans from './components/Plans.vue'
import Compare from './components/Compare.vue'
import Faq from './components/Faq.vue'
import { usePageTitle } from '~/composables/usePageTitle'

usePageTitle('Pricing')
</script>
