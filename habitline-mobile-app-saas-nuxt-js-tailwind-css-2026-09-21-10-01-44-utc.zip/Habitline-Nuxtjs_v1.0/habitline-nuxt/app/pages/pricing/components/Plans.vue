<template>
  <section class="pt-32.5 md:pt-36 lg:pt-50">
    <div class="container">
      <div class="mb-7.5 text-center">
        <span
          class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1 text-sm font-medium md:py-1.5"
        >
          Pricing plan
        </span>
        <h1
          class="text-default-900 mt-2.5 text-3xl font-medium tracking-tight md:text-5xl lg:text-[68px]"
        >
          Clear Plans for everyone
        </h1>

        <div class="mt-5 flex items-center justify-center gap-4 lg:mt-10">
          <label for="toggle-count" class="text-default-800 text-base font-medium md:text-lg"
            >Monthly</label
          >
          <input
            type="checkbox"
            id="toggle-count"
            class="peer before:bg-default-900 relative h-9 w-15 cursor-pointer appearance-none rounded-full border-2 border-transparent bg-white p-1 shadow-xl transition-colors duration-200 ease-in-out before:inline-block before:h-6 before:w-6 before:translate-x-0 before:transform before:rounded-full before:shadow before:transition before:duration-200 before:ease-in-out checked:bg-none checked:before:translate-x-full focus:ring-0 focus:ring-offset-0"
            checked
          />
          <label for="toggle-count" class="text-default-800 text-base font-medium md:text-lg"
            >Yearly</label
          >
        </div>
      </div>

      <div class="grid grid-cols-1 gap-7.5 md:grid-cols-2 lg:grid-cols-3">
        <div
          v-for="plan in plansData"
          :key="plan.name"
          :class="[
            'flex flex-col rounded-2xl bg-white p-3.5 shadow-xl md:p-5 lg:p-7.5',
            plan.cardClass,
          ]"
        >
          <div
            :class="[
              'mb-5 self-start rounded-lg px-3.75 py-1 text-sm font-medium text-white lg:py-2',
              plan.badgeClass,
            ]"
          >
            {{ plan.name }}
          </div>
          <div v-if="plan.price" class="mb-2.5 flex items-baseline gap-2 lg:mb-5">
            <p class="text-default-900 text-2xl font-semibold md:text-3xl lg:text-4xl">
              $
              <span
                :data-hs-toggle-count="
                  JSON.stringify({
                    target: '#toggle-count',
                    min: plan.price.min,
                    max: plan.price.max,
                  })
                "
                >{{ plan.price.defaultPrice }}</span
              >
            </p>
            <div class="text-lg">/per month</div>
          </div>
          <div>
            <p class="text-default-700 text-base leading-relaxed md:text-lg">
              {{ plan.description }}
            </p>
          </div>
          <div class="bg-default-200 my-6 h-px"></div>
          <ul class="mb-5 space-y-2.5 md:mb-7.5">
            <li
              v-for="feature in plan.features"
              :key="feature"
              class="text-default-600 flex items-center gap-2 text-base"
            >
              <Icon icon="lucide:circle-check" class="text-primary-2 size-4" />
              {{ feature }}
            </li>
          </ul>
          <div>
            <NuxtLink
              to=""
              class="group bg-default-900 relative inline-flex cursor-pointer items-center justify-center overflow-hidden rounded-full px-5 text-white shadow-xl! transition-all duration-300 hover:scale-95"
            >
              <div
                class="relative inline-flex flex-col items-center transition-transform duration-300 group-hover:-translate-y-full"
              >
                <div class="flex h-14 items-center gap-3">
                  <span class="font-medium">Get started</span>
                </div>
                <div class="absolute top-full flex h-14 items-center gap-3">
                  <span class="font-medium">Get started</span>
                </div>
              </div>
            </NuxtLink>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'

type PlanType = {
  name: string
  badgeClass: string
  price?: {
    min: number
    max: number
    defaultPrice: number
  }
  description: string
  features: string[]
  cardClass?: string
}

const plansData: PlanType[] = [
  {
    name: 'Free',
    badgeClass: 'bg-primary-8 shadow-[0_0_20px_rgba(0,139,183,0.4)]',
    description: 'Build habits effortlessly and stay consistent every day.',
    features: [
      'Unlimited habit tracking',
      'Daily reminders',
      'Basic streaks & progress',
      'Morning and evening routines',
      'Simple progress view',
    ],
  },
  {
    name: 'Pro plan',
    badgeClass: 'bg-primary-2',
    price: {
      min: 50,
      max: 20,
      defaultPrice: 20,
    },
    description: 'Stay consistent with smarter tools that help you track progress.',
    features: [
      'Advanced habit insights',
      'Weekly progress reports',
      'Focus & time blocks',
      'Custom reminders',
    ],
  },
  {
    name: 'Premium plan',
    badgeClass: 'bg-primary-1',
    price: {
      min: 299,
      max: 150,
      defaultPrice: 150,
    },
    description: 'Transform habits long-term with personalized insights.',
    features: [
      'Personalized habit insights',
      'Unlimited routines & stacks',
      'Priority support',
      'Early access to new features',
    ],
    cardClass: 'lg:col-span-1 md:col-span-2',
  },
]
</script>
