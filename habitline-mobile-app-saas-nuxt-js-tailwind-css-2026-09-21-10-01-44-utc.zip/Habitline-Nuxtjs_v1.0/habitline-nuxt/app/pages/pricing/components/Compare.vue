<template>
  <section class="py-20 md:py-25 lg:py-50">
    <div class="container">
      <div>
        <table class="w-full text-start">
          <thead class="bg-default-200 mb-10!">
            <tr>
              <th
                class="text-default-900 rounded-s-lg px-2 py-2.5 text-start text-sm font-medium md:p-5 md:text-xl lg:text-2xl"
              >
                Features
              </th>
              <th class="px-2 py-2.5 text-center md:p-5">
                <div class="text-default-900 text-sm font-medium md:text-xl lg:text-2xl">
                  Free plan
                </div>
                <div class="text-default-600 mt-1 text-xs font-medium md:text-lg">$0</div>
              </th>
              <th class="px-2 py-2.5 text-center md:p-5">
                <div class="text-default-900 text-sm font-medium md:text-xl lg:text-2xl">
                  Pro plan
                </div>
                <div class="text-default-600 mt-1 text-xs font-medium md:text-lg">$20/month</div>
              </th>
              <th class="rounded-r-2xl px-2 py-2.5 text-center md:p-5">
                <div class="text-default-900 text-sm font-medium md:text-xl lg:text-2xl">
                  Premium plan
                </div>
                <div class="text-default-600 mt-1 text-xs font-medium md:text-lg">$150/month</div>
              </th>
            </tr>
          </thead>
          <tbody class="text-xs md:text-base lg:text-lg">
            <tr
              v-for="(row, index) in compareData"
              :key="row.featureName"
              :class="{ 'bg-default-100': index % 2 === 0 }"
            >
              <td class="text-default-700 rounded-s-lg p-2.5 font-medium md:px-5 md:py-4">
                {{ row.featureName }}
              </td>
              <td class="text-center">
                <Icon
                  :icon="row.free ? 'lucide:circle-check' : 'lucide:circle-x'"
                  class="mx-auto size-3.75 md:size-6"
                  :class="row.free ? 'text-primary-5/50' : 'text-default-400'"
                />
              </td>
              <td class="text-center">
                <Icon
                  :icon="row.pro ? 'lucide:circle-check' : 'lucide:circle-x'"
                  class="mx-auto size-3.75 md:size-6"
                  :class="row.pro ? 'text-primary-5/50' : 'text-default-400'"
                />
              </td>
              <td class="rounded-e-lg text-center">
                <Icon
                  :icon="row.premium ? 'lucide:circle-check' : 'lucide:circle-x'"
                  class="mx-auto size-3.75 md:size-6"
                  :class="row.premium ? 'text-primary-5/50' : 'text-default-400'"
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'

type CompareType = {
  featureName: string
  free: boolean
  pro: boolean
  premium: boolean
}

const compareData: CompareType[] = [
  {
    featureName: 'Habit tracking',
    free: true,
    pro: true,
    premium: true,
  },
  {
    featureName: 'Daily reminders',
    free: true,
    pro: true,
    premium: true,
  },
  {
    featureName: 'Focus & time blocks',
    free: false,
    pro: true,
    premium: true,
  },
  {
    featureName: 'Custom reminders',
    free: false,
    pro: true,
    premium: true,
  },
  {
    featureName: 'Priority support',
    free: false,
    pro: false,
    premium: true,
  },
]
</script>
