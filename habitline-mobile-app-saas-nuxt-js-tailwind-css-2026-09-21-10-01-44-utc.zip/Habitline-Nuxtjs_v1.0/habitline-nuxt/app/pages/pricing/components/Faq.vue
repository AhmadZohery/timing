<template>
  <section class="md:pb-25 lg:pb-50">
    <div class="container">
      <div class="mb-8 space-y-3.5 text-center md:mb-12.5">
        <span
          class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1.5 text-sm font-medium"
        >
          Common Questions
        </span>
        <h3 class="text-2xl font-medium md:text-4xl lg:text-5xl">Frequently Asked Questions</h3>
      </div>

      <div class="hs-accordion-group mx-auto space-y-2.5 lg:w-3xl">
        <div
          v-for="faq in faqData"
          :key="faq.id"
          class="hs-accordion hs-accordion-active:shadow-md rounded-2xl border border-zinc-100 bg-white shadow-sm transition-all duration-300"
          :class="{ active: faq.active }"
          :id="`hs-heading-${faq.id}`"
        >
          <button
            class="hs-accordion-toggle hs-accordion-active:text-default-950 text-default-900 inline-flex w-full items-center justify-between p-3.5 text-start font-bold transition hover:text-zinc-500 lg:p-5"
            :aria-controls="`hs-collapse-${faq.id}`"
          >
            <h3 class="text-base font-medium md:text-xl">{{ faq.question }}</h3>
            <div
              class="hs-accordion-active:rotate-45 bg-default-200 relative flex size-6.5 shrink-0 items-center justify-center rounded-full transition-transform duration-300 md:size-8.5"
            >
              <Icon icon="lucide:plus" class="text-default-800 size-3 md:size-5" />
            </div>
          </button>
          <div
            :id="`hs-collapse-${faq.id}`"
            class="hs-accordion-content w-full overflow-hidden transition-[height] duration-300"
            :class="{ hidden: !faq.active }"
            :aria-labelledby="`hs-heading-${faq.id}`"
          >
            <div
              class="px-3.5 pb-3.5 text-base leading-normal text-zinc-500 md:text-lg md:leading-relaxed lg:px-5 lg:pb-5"
            >
              {{ faq.answer }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'

type FaqType = {
  id: string
  question: string
  answer: string
  active?: boolean
}

const faqData: FaqType[] = [
  {
    id: 'one',
    question: 'Is there a free plan?',
    answer:
      'Yes, Habitline offers a free plan with essential features so you can start building habits without any cost.',
    active: true,
  },
  {
    id: 'two',
    question: 'What’s included in the Pro plan?',
    answer:
      'The Pro plan includes advanced insights, focus tools, custom reminders, and detailed progress reports.',
  },
  {
    id: 'three',
    question: 'How does yearly billing work?',
    answer:
      'Yearly billing offers the same features as monthly plans at a discounted price, helping you save more over time.',
  },
  {
    id: 'four',
    question: 'Is my payment information secure?',
    answer: 'Absolutely. All payments are processed through secure, encrypted payment gateways.',
  },
  {
    id: 'five',
    question: 'Is Habitline free to use?',
    answer:
      'Habitline is free to use with essential features available at no cost. You can track habits, create routines..',
  },
]
</script>
