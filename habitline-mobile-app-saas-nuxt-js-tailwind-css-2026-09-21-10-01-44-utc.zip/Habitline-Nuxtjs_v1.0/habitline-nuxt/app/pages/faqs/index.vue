<template>
  <section class="pt-34 md:pt-42 md:pb-25 lg:pt-50">
    <div class="container">
      <div class="mb-12 space-y-3.5 text-center md:mb-25">
        <h3 class="text-3xl font-medium md:text-5xl lg:text-[68px]">Frequently Asked Questions</h3>
      </div>

      <div class="hs-accordion-group mx-auto space-y-2.5 lg:w-3xl">
        <div
          v-for="(item, idx) in faqData"
          :key="item.id"
          :class="[
            'hs-accordion hs-accordion-active:shadow-md rounded-2xl border border-zinc-100 bg-white shadow-sm transition-all duration-300',
            { active: idx === 0 },
          ]"
          :id="item.id"
        >
          <button
            class="hs-accordion-toggle hs-accordion-active:text-default-950 text-default-900 inline-flex w-full items-center justify-between p-3.5 text-start font-bold transition hover:text-zinc-500 lg:p-5"
            :aria-controls="item.collapseId"
          >
            <h3 class="text-base font-medium md:text-xl">{{ item.question }}</h3>
            <div
              class="hs-accordion-active:rotate-45 bg-default-200 relative flex size-6.5 shrink-0 items-center justify-center rounded-full transition-transform duration-300 md:size-8.5"
            >
              <Icon icon="lucide:plus" class="text-default-800 size-3 md:size-5" />
            </div>
          </button>
          <div
            :id="item.collapseId"
            :class="[
              'hs-accordion-content w-full overflow-hidden transition-[height] duration-300',
              { hidden: idx !== 0 },
            ]"
            :aria-labelledby="item.id"
          >
            <div
              class="px-3.5 pb-3.5 text-base leading-normal text-zinc-500 md:leading-relaxed lg:px-5 lg:pb-5 lg:text-lg"
            >
              {{ item.answer }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { usePageTitle } from '~/composables/usePageTitle'

type FaqType = {
  id: string
  collapseId: string
  question: string
  answer: string
}

const faqData: FaqType[] = [
  {
    id: 'hs-heading-one',
    collapseId: 'hs-collapse-one',
    question: 'Is Habitline free to use?',
    answer:
      'Yes, Habitline offers a free plan with essential features so you can start building habits without any cost.',
  },
  {
    id: 'hs-heading-two',
    collapseId: 'hs-collapse-two',
    question: 'Can I create routines for different times of day?',
    answer:
      'Yes, you can organize habits into morning, afternoon, and evening routines for better daily structure.',
  },
  {
    id: 'hs-heading-three',
    collapseId: 'hs-collapse-three',
    question: 'How does yearly billing work?',
    answer:
      'Yearly billing offers the same features as monthly plans at a discounted price, helping you save more over time.',
  },
  {
    id: 'hs-heading-four',
    collapseId: 'hs-collapse-four',
    question: 'Is my payment information secure?',
    answer: 'Absolutely. All payments are processed through secure, encrypted payment gateways.',
  },
  {
    id: 'hs-heading-five',
    collapseId: 'hs-collapse-five',
    question: 'Is Habitline free to use?',
    answer:
      'Habitline is free to use with essential features available at no cost. You can track habits, create routines.',
  },
  {
    id: 'hs-heading-six',
    collapseId: 'hs-collapse-six',
    question: 'Are there analytics or progress insights',
    answer:
      'Yes, Habitline provides clear insights to help you understand patterns and improve consistency.',
  },
  {
    id: 'hs-heading-seven',
    collapseId: 'hs-collapse-seven',
    question: 'Do you offer customer support?',
    answer: 'Yes, support is available, with priority assistance for Pro and Premium users.',
  },
]

usePageTitle('Faqs')
</script>
