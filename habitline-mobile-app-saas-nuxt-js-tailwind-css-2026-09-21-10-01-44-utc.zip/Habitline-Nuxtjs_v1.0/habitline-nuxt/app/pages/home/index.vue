<template>
  <Hero />
  <About />
  <Features />
  <Usecase />
  <Metrics />
  <Stats />
  <SmartAssist />
  <Testimonials />
  <Feedback />
  <Faq />
  <Download />
</template>

<script setup lang="ts">
import Hero from './components/Hero.vue'
import About from './components/About.vue'
import Features from './components/Features.vue'
import Usecase from './components/Usecase.vue'
import Metrics from './components/Metrics.vue'
import Stats from './components/Stats.vue'
import SmartAssist from './components/SmartAssist.vue'
import Testimonials from './components/Testimonials.vue'
import Feedback from './components/Feedback.vue'
import Faq from './components/Faq.vue'
import Download from './components/Download.vue'
import { usePageTitle } from '~/composables/usePageTitle'

usePageTitle('Home')
</script>
