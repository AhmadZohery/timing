<template>
  <section class="py-6 md:pb-10 lg:py-25">
    <div class="container">
      <div class="grid grid-cols-1 items-start gap-7.5 md:grid-cols-3 lg:grid-cols-12 lg:gap-25">
        <div class="col-span-1 space-y-10 lg:col-span-5 lg:space-y-20">
          <div class="space-y-4">
            <span
              class="border-default-200 text-default-800 mb-2.5 inline-block rounded-full border bg-white px-5 py-1.5 text-sm font-medium"
              >Common Questions</span
            >
            <h2
              class="text-default-950 text-2xl leading-normal font-medium tracking-normal md:text-4xl lg:text-5xl"
            >
              Frequently asked questions
            </h2>
          </div>
          <div class="space-y-6 rounded-2xl bg-white p-5 shadow-xl shadow-zinc-200/50 md:p-7.5">
            <div
              class="bg-primary-1 flex size-12.5 items-center justify-center rounded-full shadow-lg"
            >
              <Icon icon="lucide:headset" class="size-6 text-white" />
            </div>
            <div class="space-y-6">
              <h3 class="text-default-950 mb-3.5 text-xl font-medium md:text-2xl">
                Can't find your answer?
              </h3>
              <NuxtLink
                to="/contact"
                class="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-black px-8.5 text-nowrap text-white shadow-xl! transition-all duration-300 hover:scale-95"
              >
                <div
                  class="relative inline-flex flex-col items-center transition-transform duration-300 group-hover:-translate-y-full"
                >
                  <div class="flex h-14 items-center gap-3">
                    <span class="font-medium">Contact us</span>
                  </div>
                  <div class="absolute top-full flex h-14 items-center gap-3">
                    <span class="font-medium">Contact us</span>
                  </div>
                </div>
              </NuxtLink>
            </div>
          </div>
        </div>

        <div class="col-span-2 space-y-4 lg:col-span-7">
          <div class="hs-accordion-group space-y-2.5 lg:col-span-7 lg:space-y-4">
            <div
              v-for="item in faqData"
              :key="item.id"
              class="hs-accordion hs-accordion-active:shadow-md rounded-2xl border border-zinc-100 bg-white shadow-sm transition-all duration-300"
              :class="{ active: item.active }"
              :id="`hs-heading-${item.id}`"
            >
              <button
                class="hs-accordion-toggle hs-accordion-active:text-default-950 text-default-900 inline-flex w-full items-center justify-between p-3.5 text-start font-bold transition hover:text-zinc-500 lg:p-5"
                :aria-controls="`hs-collapse-${item.id}`"
              >
                <h3 class="text-base font-medium md:text-xl">{{ item.question }}</h3>
                <div
                  class="hs-accordion-active:rotate-45 bg-default-200 relative flex size-6.5 shrink-0 items-center justify-center rounded-full transition-transform duration-300 md:size-8.5"
                >
                  <Icon icon="lucide:plus" class="text-default-800 size-3 md:size-5" />
                </div>
              </button>
              <div
                :id="`hs-collapse-${item.id}`"
                class="hs-accordion-content w-full overflow-hidden transition-[height] duration-300"
                :class="{ hidden: !item.active }"
                :aria-labelledby="`hs-heading-${item.id}`"
              >
                <div
                  class="px-3.5 pb-3.5 text-base leading-normal text-zinc-500 md:text-lg md:leading-relaxed lg:px-5 lg:pb-5"
                >
                  {{ item.answer }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'

type FaqType = {
  id: string
  question: string
  answer: string
  active?: boolean
}

const faqData: FaqType[] = [
  {
    id: 'one',
    question: 'How many habits can I track?',
    answer: 'You can track unlimited habits, giving you complete freedom to create and organize.',
    active: true,
  },
  {
    id: 'two',
    question: 'Do reminders work across all devices?',
    answer:
      'Yes. Your reminders sync automatically and trigger on any device where Habitline is installed.',
  },
  {
    id: 'three',
    question: 'What happens if I miss a day?',
    answer:
      'If you miss a day, nothing drastic happens your progress is still saved, and you can pick up right where you left off.',
  },
  {
    id: 'four',
    question: 'Can I create routines for different times of day?',
    answer:
      'Yes, you can create routines for different times of the day. Organize your habits into morning, afternoon, or evening blocks.',
  },
  {
    id: 'five',
    question: 'Is Habitline free to use?',
    answer:
      'Habitline is free to use with essential features available at no cost. You can track habits, create routines, and set basic reminders.',
  },
]
</script>
