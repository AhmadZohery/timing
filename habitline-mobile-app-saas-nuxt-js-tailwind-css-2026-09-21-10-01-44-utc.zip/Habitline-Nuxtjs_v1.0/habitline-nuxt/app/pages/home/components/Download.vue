<template>
  <section class="relative overflow-hidden pt-20 pb-8 lg:pt-30">
    <div class="relative z-10 container">
      <div class="grid grid-cols-1 items-center gap-7.5 md:grid-cols-3 md:gap-0">
        <div
          class="order-1 flex flex-col items-center text-center md:me-10 md:text-left lg:items-start"
        >
          <h3 class="text-default-900 text-2xl font-medium tracking-tight lg:text-4xl">
            Build better habits with less effort
          </h3>
          <p class="text-default-600 mt-2.5 text-lg lg:mt-5">
            Track what matters, stay organized, and improve at your own pace.
          </p>
          <div class="relative z-40 mt-3.5 flex flex-col gap-4 lg:mt-8">
            <NuxtLink
              to="/download"
              class="group relative inline-flex overflow-hidden rounded-full bg-black px-3.5 text-white shadow-xl transition-all duration-300 hover:scale-95 lg:px-8.5"
            >
              <div
                class="relative flex flex-col items-center transition-transform duration-300 group-hover:-translate-y-full"
              >
                <div class="flex h-14 items-center gap-3">
                  <img src="/images/icons/app-store-light.svg" class="size-5" alt="" />
                  <span class="text-sm lg:text-base">Download for iPhone</span>
                </div>
                <div class="absolute top-full flex h-14 items-center gap-3">
                  <img src="/images/icons/app-store-light.svg" class="size-5" alt="" />
                  <span class="text-sm lg:text-base">Download for iPhone</span>
                </div>
              </div>
            </NuxtLink>
            <NuxtLink
              to="/download"
              class="group bg-default-200 relative inline-flex overflow-hidden rounded-full px-3.5 text-black transition-all duration-300 hover:scale-95 lg:px-8.5"
            >
              <div
                class="relative flex flex-col items-center transition-transform duration-300 group-hover:-translate-y-full"
              >
                <div class="flex h-14 items-center gap-2.5">
                  <img src="/images/icons/play-store.svg" class="size-5" alt="" />
                  <span class="text-sm lg:text-base">Get it on Android</span>
                </div>
                <div class="absolute top-full flex h-14 items-center gap-2.5">
                  <img src="/images/icons/play-store.svg" class="size-5" alt="" />
                  <span class="text-sm lg:text-base">Get it on Android</span>
                </div>
              </div>
            </NuxtLink>
          </div>
        </div>

        <div class="order-3 flex justify-center md:order-2">
          <img
            src="/images/workspace/mobile-image.png"
            alt="App Dashboard"
            class="relative z-10 w-full md:h-80 md:max-w-56 lg:h-156 lg:max-w-114"
          />
        </div>

        <div class="order-2 flex flex-col items-center md:order-3 md:ms-10 lg:items-end">
          <div class="text-center md:text-start lg:max-w-xl">
            <h3 class="text-default-900 mb-5 text-2xl font-medium tracking-tight lg:text-4xl">
              Scan the QR code to download the app
            </h3>
            <div class="relative z-30 inline-block rounded-2xl bg-white p-2 shadow-2xl">
              <div class="bg-default-200 flex items-center justify-center rounded-2xl p-2">
                <img src="/images/icons/icon-39.svg" alt="QR Code" class="size-36 lg:size-46" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        class="bg-body-bg absolute top-auto -bottom-18 left-0 z-20 h-30 w-full blur-[20px] md:h-40 md:blur-[35px] lg:-bottom-30 lg:h-55"
      ></div>
    </div>

    <img
      src="/images/locations/cloud-04.webp"
      alt=""
      class="pointer-events-none absolute -bottom-12.5 -left-25 -z-20 h-72.5 w-218"
    />
    <img
      src="/images/locations/cloud-01.webp"
      alt=""
      class="pointer-events-none absolute inset-e-25 -bottom-25 -z-6 h-72.5 w-224 -translate-x-1/2 lg:z-10"
    />
    <img
      src="/images/locations/cloud-04.webp"
      alt=""
      class="pointer-events-none absolute inset-e-0 top-auto -bottom-50 z-0 h-87.5 w-full"
    />
  </section>
</template>

<script setup lang="ts">
import { NuxtLink } from '#components'
</script>
