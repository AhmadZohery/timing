<template>
  <section class="relative overflow-hidden py-20 lg:py-40">
    <div class="container">
      <div class="relative overflow-hidden lg:max-h-180">
        <div class="grid grid-cols-2 gap-3.5 md:gap-5 lg:grid-cols-3 lg:gap-7.5">
          <div class="space-y-3.5 md:space-y-5 lg:space-y-7.5">
            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                Habitline made my mornings feel manageable again.
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-04.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Maya Zong"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Maya Zong
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Student</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>

            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                The weekly insights are what sold me. They show exactly where I fall off and help me
                adjust without feeling guilty or overwhelmed.
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-05.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Aaron Chope"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Aaron Chope
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Product Designer</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>

            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                I actually stick to my routines now. Small steps finally add up
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-06.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Hannah Kang"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Hannah Kang
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Nurse</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>
          </div>

          <div class="space-y-3.5 md:space-y-5 lg:space-y-7.5">
            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                I used to ignore reminders from other apps, but these feel calm and well-timed. It’s
                like the app knows when I’m actually able to do something.
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-07.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Sofia"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Daniel
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Remote Engineer</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>

            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                Focus blocks changed the way I work. I get more done in two hours now than what used
                to take half a day.
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-08.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Maya Zong"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Maya Zong
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Student</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>

            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                The gentle reminders help me stay consistent without feeling pressured.
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-02.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Riya Patel"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Riya Patel
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Marketing Associate</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>
          </div>

          <div class="space-y-3.5 md:space-y-5 lg:space-y-7.5">
            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                It’s the first habit app that doesn’t overwhelm me.
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-09.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Sofia"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Sofia
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Fitness Enthusiast</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>

            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                Habitline keeps me grounded. Even on hectic days.
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-01.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Arjun Mehta"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Arjun Mehta
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Software Developer</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>

            <div class="bg-default-200 flex flex-col justify-between rounded-2xl p-2.5 md:p-7.5">
              <p
                class="text-default-800 mb-3.5 text-sm leading-snug font-medium md:mb-7.5 md:text-lg"
              >
                I’ve finally stopped procrastinating. Habitline helped me break my goals into steps
                I can manage. I complete tasks in half the time I used to.
              </p>
              <div class="flex items-center justify-between">
                <div class="items-center gap-2.5 md:flex">
                  <img
                    src="/images/team/avatar-03.webp"
                    class="size-7.5 rounded-full object-cover md:size-12"
                    alt="Meera Shah"
                  />
                  <div class="mt-1.25 md:mt-0">
                    <h3 class="text-default-900 text-sm leading-none font-medium md:text-lg">
                      Meera Shah
                    </h3>
                    <p class="text-default-500 mt-1 text-xs md:text-sm">Content Writer</p>
                  </div>
                </div>
                <NuxtLink
                  to=""
                  target="_blank"
                  class="group inline-flex size-5.5 items-center justify-center overflow-hidden rounded-full bg-white md:size-10"
                >
                  <div class="relative size-4 overflow-hidden">
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full transition-transform duration-300 group-hover:-translate-y-[200%]"
                    />
                    <Icon
                      icon="tabler:brand-x-filled"
                      class="text-default-800 absolute inset-0 size-4 h-full w-full translate-y-[200%] transition-transform duration-300 group-hover:translate-y-0"
                    />
                  </div>
                </NuxtLink>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'
</script>
