<template>
  <section class="pb-25 lg:pb-50" id="smart-assist">
    <div class="container">
      <div class="mb-20 grid grid-cols-1 items-center gap-7.5 md:grid-cols-2">
        <div>
          <span
            class="border-default-200 text-default-800 mb-2.5 inline-block rounded-full border bg-white px-5 py-1.5 text-sm font-medium"
            >Smarter habits, less thinking</span
          >
          <h3
            class="text-default-900 mb-2.5 text-3xl leading-tight font-medium tracking-tight md:text-4xl lg:text-5xl"
          >
            AI suggestions that
            <br class="hidden md:block" />
            adjust to your day
          </h3>
          <p
            class="text-default-500 mb-6 max-w-lg text-base leading-normal md:text-lg md:leading-relaxed"
          >
            Habitline learns your patterns and offers small, useful suggestions that help you stay
            consistent without guessing what to do next.
          </p>
          <div>
            <NuxtLink
              to="/about"
              class="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-black px-8.5 text-white shadow-xl! transition-all duration-300 hover:scale-95"
            >
              <div
                class="relative inline-flex flex-col items-center transition-transform duration-300 group-hover:-translate-y-full"
              >
                <div class="flex h-14 items-center gap-3">
                  <span class="font-medium">See how suggestions work</span>
                </div>
                <div class="absolute top-full flex h-14 items-center gap-3">
                  <span class="font-medium">See how suggestions work</span>
                </div>
              </div>
            </NuxtLink>
          </div>
        </div>

        <div
          class="group relative mx-auto flex h-100 w-full items-center justify-center overflow-hidden rounded-2xl bg-[url('/images/workspace/suggestion-image.webp')] shadow-2xl md:aspect-video lg:aspect-[4/3] lg:h-142 lg:max-w-4xl"
        >
          <div
            class="absolute top-10 -right-16 transition-transform duration-700 ease-out md:top-20"
          >
            <img
              src="/images/workspace/dashboard-07.png"
              alt="Smartphone Mockup"
              class="h-auto -rotate-20 lg:w-xs"
            />
          </div>
          <div
            class="absolute top-12 left-6 z-30 hidden flex-col gap-4 md:top-20 md:left-12 lg:flex"
          >
            <div class="animate-float">
              <img
                src="/images/workspace/dashboard-06.svg"
                alt="Suggestion 01"
                class="w-48 md:w-64"
              />
            </div>
            <div class="animate-float">
              <img
                src="/images/workspace/dashboard-05.svg"
                alt="Suggestion 02"
                class="ms-2 w-48 md:ms-4 md:w-64"
              />
            </div>
            <div class="animate-float">
              <img
                src="/images/workspace/dashboard-04.svg"
                alt="Suggestion 03"
                class="w-48 md:w-64"
              />
            </div>
          </div>
          <div class="animate-pulse-slow absolute bottom-20 left-40 z-30 hidden lg:block">
            <div>
              <img
                src="/images/icons/icon-30.svg"
                alt="AI Icon"
                class="size-18 rounded-2xl shadow-inner"
              />
            </div>
          </div>
          <div
            class="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/5 to-transparent"
          ></div>
        </div>
      </div>

      <div class="mt-24 grid grid-cols-2 gap-2.5 md:gap-7.5 lg:grid-cols-4">
        <div
          v-for="item in smartAssistData"
          :key="item.title"
          class="group flex flex-col justify-end gap-y-6.5 rounded-2xl bg-white p-3.5 md:gap-y-10 md:p-5 lg:gap-y-17.5 lg:p-7.5"
        >
          <div :class="['flex size-12.5 items-center justify-center rounded-full', item.bgClass]">
            <Icon v-if="item.icon" :icon="item.icon" class="text-xl text-white" />
            <img v-else-if="item.image" :src="item.image" alt="" />
          </div>
          <div>
            <h4 :class="['text-default-900 mb-2.5 font-medium', item.titleClass]">
              {{ item.title }}
            </h4>
            <p class="text-default-700 text-sm leading-normal md:text-lg">{{ item.description }}</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'

type SmartAssistType = {
  title: string
  description: string
  bgClass: string
  icon?: string
  image?: string
  titleClass?: string
}

const smartAssistData: SmartAssistType[] = [
  {
    title: 'Reminder Timing',
    description: 'Suggests the best time to remind you.',
    bgClass: 'bg-primary-3',
    icon: 'lucide:bell-dot',
    titleClass: 'md:text-2xl text-xl',
  },
  {
    title: 'Habit Priorities',
    description: 'Reorders habits on busy days.',
    bgClass: 'bg-primary-7',
    image: '/images/icons/icon-32.svg',
    titleClass: 'md:text-2xl text-xl',
  },
  {
    title: 'Routine Insights',
    description: 'Highlights what’s working and what’s slipping.',
    bgClass: 'bg-primary-6',
    icon: 'lucide:eye',
    titleClass: 'md:text-2xl text-xl',
  },
  {
    title: 'Recovery suggestion',
    description: 'Helps you recover when you miss a day.',
    bgClass: 'bg-primary-2',
    icon: 'lucide:lightbulb',
    titleClass: 'md:text-[21px] text-xl',
  },
]
</script>
