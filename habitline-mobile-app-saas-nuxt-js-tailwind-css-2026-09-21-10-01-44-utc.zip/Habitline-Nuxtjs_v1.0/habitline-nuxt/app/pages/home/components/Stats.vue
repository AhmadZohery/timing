<template>
  <section class="relative overflow-hidden pb-20 md:pb-25 lg:pb-46">
    <div class="container">
      <div class="mb-2 text-center">
        <span
          class="border-default-200 text-default-800 mb-3.5 inline-block rounded-full border bg-white px-5 py-1.5 text-sm font-medium"
          >Real habits, real numbers</span
        >
        <h2 class="text-default-900 text-3xl font-medium md:text-4xl lg:text-5xl">
          How people stay
          <br />
          consistent over time
        </h2>
      </div>
      <div class="relative z-20 mb-7.5 flex flex-col items-center justify-center">
        <div class="relative items-center md:inline-flex">
          <h3
            class="text-primary-1 ms-8 text-4xl leading-none font-black tracking-normal md:ms-0 md:text-[100px] lg:text-[120px]"
          >
            62,000
            <span class="ms-1">+</span>
          </h3>
          <div
            class="-inset-e-12 mt-1 rounded-2xl bg-white px-2 py-2 whitespace-nowrap shadow-xl md:absolute md:top-20 md:-right-20 md:rotate-8 md:px-5"
          >
            <p class="text-default-800 text-xs font-bold md:text-sm">Check-ins logged last month</p>
          </div>
        </div>
      </div>
      <div class="relative mx-auto flex h-100 flex-col items-center justify-start md:h-138">
        <img src="/images/workspace/glob-image.png" class="hidden w-full object-cover" />
        <div class="bg-body-bg h-full w-full overflow-hidden">
          <div
            class="mix-blinset-e-darken bg-body-bg relative z-20 h-75 overflow-hidden md:h-125 lg:h-200"
          >
            <video
              autoplay
              loop
              muted
              playsinline
              class="absolute -inset-300 z-[-100] m-auto size-full bg-[url('/images/workspace/hero-glob.jpg')] bg-cover bg-center object-cover"
            >
              <source src="/videos/hero-glob.mp4" />
            </video>
          </div>
          <img
            src="/images/locations/cloud-06.webp"
            alt="Decoration"
            class="absolute -inset-s-20 inset-e-0 top-auto bottom-40 z-20 h-40 w-full md:bottom-30 md:h-62.5 lg:bottom-2"
          />
          <img
            src="/images/locations/cloud-01.webp"
            alt="Decoration Image"
            class="absolute -inset-s-7.5 inset-e-0 top-auto bottom-20 z-20 w-full md:-bottom-25 md:h-112 lg:-bottom-50"
          />
          <img
            src="/images/locations/cloud-01.webp"
            alt="Decoration Image"
            class="absolute inset-s-auto -inset-e-25 top-auto bottom-3 z-20 h-75 w-full md:-bottom-5 lg:-inset-e-62.5 lg:-bottom-25 lg:h-112"
          />
        </div>
        <div
          class="z-40 mx-auto -mt-50 grid grid-cols-2 items-start gap-6 text-center md:-mt-60 md:w-3xl md:grid-cols-3 lg:-mt-0 lg:gap-17.5"
        >
          <div class="flex flex-col items-center">
            <div class="flex items-baseline gap-1">
              <h3
                class="text-default-900 text-3xl font-medium tracking-normal md:text-5xl lg:text-7xl"
              >
                87
              </h3>
              <span class="text-primary-6 text-3xl font-medium md:text-5xl lg:text-6xl">%</span>
            </div>
            <p class="text-default-800 mt-2 text-sm leading-tight font-semibold md:text-lg">
              Faster AI execution
            </p>
          </div>
          <div class="flex flex-col items-center">
            <h3
              class="text-default-900 text-3xl font-medium tracking-normal md:text-5xl lg:text-7xl"
            >
              46
            </h3>
            <p class="text-default-800 mt-2 text-sm leading-tight font-semibold md:text-lg">
              Sessions completed on average
            </p>
          </div>
          <div class="col-span-2 flex flex-col items-center md:col-span-1">
            <div class="flex items-baseline gap-1">
              <h3
                class="text-default-900 text-3xl font-medium tracking-normal md:text-5xl lg:text-7xl"
              >
                32
              </h3>
              <span class="text-primary-3 text-3xl font-medium md:text-5xl lg:text-6xl">+</span>
            </div>
            <p class="text-default-800 mt-2 text-sm leading-tight font-semibold md:text-lg">
              Countries with active Habitline users
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts"></script>
