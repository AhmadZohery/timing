<template>
  <section class="py-25 lg:py-50" id="metrics">
    <div class="container">
      <div
        class="mb-8 flex flex-col items-end justify-between gap-4 md:mb-12.5 md:flex-row md:gap-8"
      >
        <h2
          class="text-default-900 text-3xl leading-tight font-medium tracking-tight md:w-lg md:text-4xl lg:text-5xl"
        >
          What users are achieving with Habitline
        </h2>
        <div
          class="flex flex-col items-start justify-start space-y-2.5 text-start md:items-end md:justify-end"
        >
          <div class="flex items-center justify-start md:justify-end">
            <div class="flex -space-x-4">
              <img
                class="border-default-800 h-10 w-10 rounded-full border-2 object-cover"
                src="/images/team/avatar-01.webp"
                alt="User"
              />
              <img
                class="border-default-800 h-10 w-10 rounded-full border-2 object-cover"
                src="/images/team/avatar-02.webp"
                alt="User"
              />
              <img
                class="border-default-800 h-10 w-10 rounded-full border-2 object-cover"
                src="/images/team/avatar-03.webp"
                alt="User"
              />
              <div
                class="border-default-800 bg-default-900 flex h-10 w-10 items-center justify-center rounded-full border-2 text-[8px] font-medium text-white"
              >
                You?
              </div>
            </div>
          </div>
          <div class="text-primary-1 flex gap-1.75">
            <Icon icon="tabler:star-filled" class="size-4" />
            <Icon icon="tabler:star-filled" class="size-4" />
            <Icon icon="tabler:star-filled" class="size-4" />
            <Icon icon="tabler:star-filled" class="size-4" />
            <Icon icon="tabler:star-filled" class="size-4" />
          </div>
          <div class="text-default-600 text-lg font-medium">Trusted worldwide</div>
        </div>
      </div>
    </div>

    <div class="relative flex gap-7.5 overflow-hidden">
      <div v-for="n in 2" :key="n" class="animate-marquee flex gap-7.5 py-4 whitespace-nowrap">
        <div
          v-for="(card, cardIdx) in metricsData"
          :key="cardIdx"
          class="group relative flex h-75 w-95 flex-col justify-between overflow-hidden rounded-2xl p-7.5 md:h-128"
        >
          <img
            :src="card.image"
            class="absolute inset-0 h-full w-full object-cover"
            :alt="card.alt"
          />
          <div
            class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20"
          ></div>
          <div class="relative z-10">
            <p class="text-lg font-medium text-white">
              <span v-if="card.nameWrapped">{{ card.name }}</span>
              <template v-else>{{ card.name }}</template>
              <span :class="['opacity-50', card.roleClass]">— {{ card.role }}</span>
            </p>
          </div>
          <div class="relative z-10 text-white">
            <div v-if="card.metric">
              <h3 :class="['mb-1 font-black text-white', card.metric.sizeClass]">
                {{ card.metric.value }}
              </h3>
              <p class="font-medium text-white">{{ card.metric.label }}</p>
            </div>
            <p v-else class="text-lg leading-tight font-medium whitespace-normal text-white">
              {{ card.text }}
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'

type MetricCardType = {
  name: string
  role: string
  image: string
  alt: string
  nameWrapped?: boolean
  roleClass: string
  text?: string
  metric?: {
    value: string
    label: string
    sizeClass: string
  }
}

const metricsData: MetricCardType[] = [
  {
    name: 'Maya',
    role: 'Student',
    image: '/images/about/social-image-01.webp',
    alt: 'Student',
    nameWrapped: true,
    roleClass: 'text-sm font-medium',
    text: 'Completed 21-day streak using Habitline',
  },
  {
    name: 'Daniel Gray',
    role: 'Founder',
    image: '/images/about/social-image-02.webp',
    alt: 'User',
    nameWrapped: false,
    roleClass: 'font-normal',
    metric: {
      value: '87%',
      label: 'Improved weekly consistency',
      sizeClass: 'text-5xl',
    },
  },
  {
    name: 'Aaron Lee',
    role: 'Remote Engineer',
    image: '/images/about/social-image-03.webp',
    alt: 'User',
    nameWrapped: false,
    roleClass: 'font-normal',
    text: 'Stopped breaking habits on weekends after switching to Habitline',
  },
  {
    name: 'Priya',
    role: 'Busy Parent',
    image: '/images/about/social-image-04.webp',
    alt: 'Parent',
    nameWrapped: true,
    roleClass: 'text-sm font-medium',
    text: 'Logged 40 focus sessions this month with Routine Stacks',
  },
  {
    name: 'Leo',
    role: 'Creative Professional',
    image: '/images/about/social-image-05.webp',
    alt: 'Leo',
    nameWrapped: true,
    roleClass: 'text-sm font-medium',
    metric: {
      value: '10 days',
      label: 'Hit hydration goals',
      sizeClass: 'text-4xl',
    },
  },
  {
    name: 'Ravi',
    role: 'Software Developer',
    image: '/images/about/social-image-06.webp',
    alt: 'Software Developer',
    nameWrapped: true,
    roleClass: 'text-sm font-medium',
    text: 'Finally keeps his day organized with routine-based habit groups',
  },
]
</script>
