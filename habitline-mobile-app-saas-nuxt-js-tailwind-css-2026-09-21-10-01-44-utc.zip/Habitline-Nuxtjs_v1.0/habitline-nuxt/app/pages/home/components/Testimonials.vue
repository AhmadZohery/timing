<template>
  <section class="relative overflow-hidden pb-25 text-white">
    <div class="container">
      <div class="mx-auto mb-8 text-center md:mb-12.5">
        <span
          class="border-default-200 text-default-800 mb-2.5 inline-block rounded-full border bg-white px-5 py-1.5 text-sm font-medium"
          >A closer look</span
        >
        <h2
          class="text-default-950 mb-2.5 text-2xl font-semibold tracking-normal md:text-4xl lg:text-5xl"
        >
          How people use
          <br />
          Habitline every day
        </h2>
        <div
          class="mt-5 inline-flex flex-wrap items-center justify-center gap-2 rounded-full text-sm md:gap-2.5"
        >
          <span class="text-default-800 text-lg font-semibold">4.5/5.0</span>
          <div class="flex items-center gap-2">
            <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
            <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
            <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
            <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
            <Icon icon="tabler:star-filled" class="text-primary-1 size-4" />
          </div>
          <span class="text-default-600 text-base md:text-lg">(Trusted by 1582+ users)</span>
        </div>
      </div>

      <div class="relative">
        <div v-lightgallery class="swiper storySwiper overflow-visible">
          <Swiper
            :modules="[Navigation]"
            :slides-per-view="1"
            :centered-slides="true"
            :space-between="15"
            :loop="true"
            :speed="700"
            :navigation="{
              nextEl: '.story-next',
              prevEl: '.story-prev',
            }"
            :breakpoints="{
              768: { slidesPerView: 3 },
              1024: { slidesPerView: 3 },
            }"
            class="swiper-wrapper"
          >
            <SwiperSlide v-for="(item, index) in testimonialsData" :key="index">
              <div class="group relative overflow-hidden rounded-2xl">
                <video
                  autoplay
                  muted
                  loop
                  playsinline
                  class="h-106 w-84 object-cover"
                  :poster="item.poster"
                >
                  <source :src="item.video" type="video/mp4" />
                </video>
                <div :class="['absolute inset-0 bg-gradient-to-t', item.overlayClass]"></div>
                <div class="absolute top-5 left-5 z-20 flex items-center gap-3">
                  <img
                    :src="item.avatar"
                    alt=""
                    class="max-h-10 min-h-10 max-w-10 min-w-10 shrink-0 rounded-full border border-white/20 object-cover"
                  />
                  <div class="text-start">
                    <h3 class="text-sm leading-none font-semibold text-white">{{ item.name }}</h3>
                    <p class="mt-1 text-sm text-white/70">{{ item.role }}</p>
                  </div>
                </div>
                <div class="absolute right-5 bottom-5 z-20">
                  <a
                    :href="item.videoUrl"
                    class="text-default-950 flex items-center gap-2 rounded-sm bg-white/20 px-2 py-1 backdrop-blur-md transition duration-300 hover:bg-white/30"
                    data-toggle="video"
                  >
                    <span class="flex items-center justify-center">
                      <Icon icon="tabler:player-play-filled" class="size-3.5" />
                    </span>
                    <span class="text-sm font-medium">Play</span>
                  </a>
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>

        <button
          class="story-prev bg-default-200 hover:bg-primary-2 absolute -bottom-18 left-30 z-20 flex size-10 items-center justify-center rounded-full md:left-80 lg:left-140"
        >
          <Icon icon="lucide:chevron-left" class="text-default-800 size-6" />
        </button>
        <button
          class="story-next bg-default-200 hover:bg-primary-2 absolute right-30 -bottom-18 z-20 flex size-10 items-center justify-center rounded-full md:right-80 lg:right-138"
        >
          <Icon icon="lucide:chevron-right" class="text-default-800 size-6" />
        </button>

        <div
          class="bg-body-bg pointer-events-none absolute inset-y-0 -left-20 z-20 hidden w-37.5 blur-[20px] md:block"
        ></div>
        <div
          class="bg-body-bg pointer-events-none absolute inset-y-0 -right-20 z-20 hidden w-37.5 blur-[30px] md:block"
        ></div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { Swiper, SwiperSlide } from 'swiper/vue'
import { Navigation } from 'swiper/modules'

type TestimonialType = {
  video: string
  poster?: string
  overlayClass: string
  avatar: string
  name: string
  role: string
  videoUrl: string
}

const testimonialsData: TestimonialType[] = [
  {
    video: '/videos/story-slider-01.mp4',
    poster: '/images/event/story-slider-01_poster.jpg',
    overlayClass: 'from-black/80 via-black/20 to-black/40',
    avatar: '/images/team/avatar-09.webp',
    name: 'Marcus Reed',
    role: 'Fitness Instructor',
    videoUrl: 'https://www.youtube.com/embed/elgqxmdVms8?si=yYfzbunShGP15tde',
  },
  {
    video: '/videos/story-slider-02.mp4',
    poster: '/images/event/story-slider-02_poster.jpg',
    overlayClass: 'from-black/90 via-black/20 to-transparent',
    avatar: '/images/team/avatar-08.webp',
    name: 'Aisha Khan',
    role: 'Digital Marketer',
    videoUrl: 'https://www.youtube.com/embed/elgqxmdVms8?si=yYfzbunShGP15tde',
  },
  {
    video: '/videos/story-slider-03.mp4',
    poster: '/images/event/story-slider-03_poster.jpg',
    overlayClass: 'from-black/90 via-black/20 to-transparent',
    avatar: '/images/team/avatar-07.webp',
    name: 'Daniel',
    role: 'Remote Engineer',
    videoUrl: 'https://www.youtube.com/embed/elgqxmdVms8?si=yYfzbunShGP15tde',
  },
  {
    video: '/videos/story-slider-04.mp4',
    overlayClass: 'from-black/90 via-black/20 to-transparent',
    avatar: '/images/team/avatar-04.webp',
    name: 'Olivia Park',
    role: 'Project Manager',
    videoUrl: 'https://www.youtube.com/embed/elgqxmdVms8?si=yYfzbunShGP15tde',
  },
  {
    video: '/videos/story-slider-05.mp4',
    overlayClass: 'from-black/90 via-black/20 to-transparent',
    avatar: '/images/team/avatar-05.webp',
    name: 'Ryan Cooper',
    role: 'Software Developer',
    videoUrl: 'https://www.youtube.com/embed/elgqxmdVms8?si=yYfzbunShGP15tde',
  },
]
</script>
