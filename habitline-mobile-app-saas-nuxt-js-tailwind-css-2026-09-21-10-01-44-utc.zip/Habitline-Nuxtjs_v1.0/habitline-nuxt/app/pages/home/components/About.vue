<template>
  <section class="relative pb-20 text-center lg:pt-6 lg:pb-50">
    <div class="container">
      <div class="md:mb-15">
        <h2
          class="mx-auto mb-10 max-w-5xl text-center text-3xl leading-tight font-medium tracking-tight text-black md:text-5xl"
        >
          Build steady daily
          <span
            class="relative inline-flex h-6.5 w-12.5 overflow-hidden rounded-full align-middle md:h-11 md:w-22.5"
          >
            <img
              src="/images/about/about-01.webp"
              class="animate-imageSwap absolute inset-0 h-full w-full object-cover"
              alt=""
            />
            <img
              src="/images/about/about-02.webp"
              class="animate-imageSwap2 absolute inset-0 h-full w-full object-cover"
              alt=""
            />
            <img
              src="/images/about/about-03.webp"
              class="animate-imageSwap3 absolute inset-0 h-full w-full object-cover"
              alt=""
            />
            <img
              src="/images/about/about-04.webp"
              class="animate-imageSwap4 absolute inset-0 h-full w-full object-cover"
              alt=""
            />
          </span>
          habits with a layout
          <br class="hidden lg:block" />
          that keeps your mornings, evenings,
          <span class="mx-1 inline-flex align-middle">
            <img src="/images/icons/icon-19.svg" alt="Icon" class="size-7.5 md:size-15" />
          </span>
          and focus hours simple to follow.
        </h2>
        <p class="text-default-500 mb-3.5 text-base font-medium md:text-xl lg:text-2xl">
          Used by people to improve their routines.
        </p>
        <div class="flex flex-wrap justify-center gap-3.5">
          <span
            class="bg-default-200 text-default-800 rounded-full px-3.5 py-2 text-sm font-semibold"
            >#Founders</span
          >
          <span
            class="bg-default-200 text-default-800 rounded-full px-3.5 py-2 text-sm font-semibold"
            >#Students</span
          >
          <span
            class="bg-default-200 text-default-800 rounded-full px-3.5 py-2 text-sm font-semibold"
            >#BusyParents</span
          >
          <span
            class="bg-default-200 text-default-800 rounded-full px-3.5 py-2 text-sm font-semibold"
            >#RemoteTeams</span
          >
        </div>
      </div>
      <div class="relative flex w-full flex-col items-center overflow-hidden py-12 md:py-24">
        <div
          class="bg-body-bg pointer-events-none absolute inset-y-0 -left-20 z-20 hidden w-37.5 blur-[20px] md:block"
        ></div>
        <div
          class="bg-body-bg pointer-events-none absolute inset-y-0 -right-20 z-20 hidden w-37.5 blur-[30px] md:block"
        ></div>
        <div class="mt-10 overflow-hidden py-6 md:mt-20">
          <div class="animate-marquee-left flex w-max gap-5">
            <div v-for="n in 2" :key="n" class="flex items-center gap-5">
              <template v-for="item in aboutData" :key="item.title">
                <div
                  class="inline-flex size-32.5 flex-col items-center justify-center gap-5 rounded-3xl bg-white p-5 shadow-xl md:size-37.5"
                >
                  <div
                    :class="[
                      'flex size-7.5 shrink-0 items-center justify-center rounded-full md:size-12.5',
                      item.bgClass,
                    ]"
                  >
                    <img
                      :src="item.icon"
                      class="size-3.5 md:size-6"
                      :class="{ invert: item.invert }"
                      alt=""
                    />
                  </div>
                  <span class="text-default-800 text-center text-sm font-medium md:text-base">{{
                    item.title
                  }}</span>
                </div>
                <img
                  :src="item.image"
                  class="size-32.5 rounded-3xl object-cover shadow-lg md:size-37.5"
                  alt=""
                />
              </template>
            </div>
          </div>
        </div>
        <div class="overflow-hidden pb-6 md:mb-20">
          <div class="animate-marquee-right flex w-max gap-5">
            <div v-for="n in 2" :key="n" class="flex items-center gap-5">
              <template v-for="item in aboutData" :key="item.title">
                <div
                  class="inline-flex size-32.5 flex-col items-center justify-center gap-5 rounded-3xl bg-white p-5 shadow-xl md:size-37.5"
                >
                  <div
                    :class="[
                      'flex size-7.5 shrink-0 items-center justify-center rounded-full md:size-12.5',
                      item.bgClass,
                    ]"
                  >
                    <img
                      :src="item.icon"
                      class="size-3.5 md:size-6"
                      :class="{ invert: item.invert }"
                      alt=""
                    />
                  </div>
                  <span class="text-default-800 text-center text-sm font-medium md:text-base">{{
                    item.title
                  }}</span>
                </div>
                <img
                  :src="item.image"
                  class="size-32.5 rounded-3xl object-cover shadow-lg md:size-37.5"
                  alt=""
                />
              </template>
            </div>
          </div>
        </div>
        <div class="pointer-events-none absolute inset-0 z-30 flex items-center justify-center">
          <img
            src="/images/event/phone-image.png"
            class="h-88 w-42 md:h-175 md:w-85"
            alt="App Interface"
          />
        </div>
      </div>
      <div class="mx-auto mt-4 flex flex-col items-center gap-y-5 px-6 md:mt-12">
        <div
          class="border-default-200 flex items-center gap-2 rounded-full border bg-white px-2.5 py-2 md:px-5"
        >
          <Icon icon="tabler:star-filled" class="text-primary-1 size-3.5" />
          <p class="text-default-500 text-sm font-medium">
            <span class="font-medium text-black">4.7 rating</span> (based on 125 reviews)
          </p>
        </div>
        <p class="text-default-700 mb-2.5 w-xs text-base leading-normal md:w-xl md:text-lg">
          Stay consistent with a system that fits into real life. Simple cards, clear routines, and
          gentle nudges help you build progress that lasts.
        </p>
        <div class="flex w-full flex-col justify-center gap-5 md:flex-row">
          <NuxtLink
            to="/download"
            class="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-black px-8.5 text-white shadow-xl! transition-all duration-300 hover:scale-95"
          >
            <div
              class="relative flex flex-col items-center transition-transform duration-300 group-hover:-translate-y-full"
            >
              <div class="flex h-14 items-center gap-3">
                <img src="/images/icons/app-store-light.svg" class="h-5 w-5" alt="" />
                <span class="font-normal">Download for iPhone</span>
              </div>
              <div class="absolute top-full flex h-14 items-center gap-3">
                <img src="/images/icons/app-store-light.svg" class="h-5 w-5" alt="" />
                <span class="font-normal">Download for iPhone</span>
              </div>
            </div>
          </NuxtLink>
          <NuxtLink
            to="/download"
            class="group bg-default-200 relative inline-flex items-center justify-center overflow-hidden rounded-full px-8.5 text-black transition-all duration-300 hover:scale-95"
          >
            <div
              class="relative flex flex-col items-center transition-transform duration-300 group-hover:-translate-y-full"
            >
              <div class="flex h-14 items-center gap-2.5">
                <img src="/images/icons/play-store.svg" class="h-5 w-5" alt="" />
                <span class="font-normal">Get it on Android</span>
              </div>
              <div class="absolute top-full flex h-14 items-center gap-2.5">
                <img src="/images/icons/play-store.svg" class="h-5 w-5" alt="" />
                <span class="font-normal">Get it on Android</span>
              </div>
            </div>
          </NuxtLink>
        </div>
      </div>
    </div>
    <div class="relative hidden lg:block">
      <img
        src="/images/locations/cloud-04.webp"
        loading="lazy"
        alt="Decoration Image"
        class="absolute inset-s-0 inset-e-0 -bottom-100 -z-5 h-148 w-full object-cover"
      />
      <img
        src="/images/locations/cloud-02.webp"
        loading="lazy"
        alt="Decoration Image"
        class="absolute inset-e-0 -bottom-38 -z-5 h-75"
      />
      <img
        src="/images/locations/cloud-01.webp"
        loading="lazy"
        alt="Decoration Image"
        class="absolute inset-s-0 -bottom-48 -z-5 h-75"
      />
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'

type AboutType = {
  title: string
  icon: string
  bgClass: string
  image: string
  invert?: boolean
}

const aboutData: AboutType[] = [
  {
    title: 'Phone off by 10:30',
    icon: '/images/icons/icon-11.svg',
    bgClass: 'bg-primary-8',
    image: '/images/gallery/marquee-image-01.webp',
  },
  {
    title: 'Morning walk',
    icon: '/images/icons/icon-12.svg',
    bgClass: 'bg-primary-1',
    image: '/images/gallery/marquee-image-02.webp',
    invert: true,
  },
  {
    title: 'Focus session',
    icon: '/images/icons/icon-13.svg',
    bgClass: 'bg-primary-2',
    image: '/images/gallery/marquee-image-03.webp',
    invert: true,
  },
  {
    title: 'Stretch for 5 minutes',
    icon: '/images/icons/icon-14.svg',
    bgClass: 'bg-primary-3',
    image: '/images/gallery/marquee-image-04.webp',
    invert: true,
  },
  {
    title: 'Clean workspace',
    icon: '/images/icons/icon-15.svg',
    bgClass: 'bg-primary-7',
    image: '/images/gallery/marquee-image-05.webp',
    invert: true,
  },
  {
    title: 'Meditate',
    icon: '/images/icons/icon-16.svg',
    bgClass: 'bg-primary-6',
    image: '/images/gallery/marquee-image-06.webp',
    invert: true,
  },
  {
    title: 'Track water',
    icon: '/images/icons/icon-17.svg',
    bgClass: 'bg-primary-5',
    image: '/images/gallery/marquee-image-07.webp',
    invert: true,
  },
  {
    title: 'Write journal',
    icon: '/images/icons/icon-18.svg',
    bgClass: 'bg-primary-4',
    image: '/images/gallery/marquee-image-08.webp',
    invert: true,
  },
]
</script>
