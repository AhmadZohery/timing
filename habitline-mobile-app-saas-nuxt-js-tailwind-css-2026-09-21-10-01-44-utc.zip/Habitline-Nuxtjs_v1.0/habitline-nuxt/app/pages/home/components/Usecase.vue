<template>
  <section class="relative" id="usecase">
    <div
      class="pointer-events-none absolute inset-0 z-0 opacity-60"
      style="
        background-image: radial-gradient(#e5e7eb 1.5px, transparent 1.5px);
        background-size: 24px 24px;
      "
    ></div>
    <div
      class="relative z-10 container rounded-2xl bg-white bg-[url('/images/icons/vector-10.png')] object-cover p-8.5 text-center lg:mx-auto lg:p-25"
    >
      <span
        class="border-default-200 text-default-800 mb-3.5 inline-block rounded-full border bg-white px-5 py-1.5 text-sm font-medium"
        >Fits every lifestyle</span
      >
      <h2
        class="text-default-900 mb-8 text-2xl leading-[1.1] font-medium tracking-normal md:mb-12.5 md:text-4xl lg:text-5xl"
      >
        Adapted for the way
        <br class="hidden md:block" />
        you live and work
      </h2>
      <nav
        class="mb-7.5 flex flex-wrap justify-center gap-2.5 md:gap-5"
        aria-label="Tabs"
        role="tablist"
      >
        <button
          v-for="tab in usecasesData"
          :key="tab.id"
          type="button"
          class="hs-tab-active:border-default-800 hs-tab-active:bg-default-100 hs-tab-active:text-default-900 bg-default-100 border-default-200 text-default-500 hover:bg-default-100 inline-flex items-center gap-x-2.5 rounded-xl border px-5 py-2.5 text-base font-medium transition-all md:text-lg"
          :class="{ active: tab.active }"
          :id="`tabs-item-${tab.id}`"
          :data-hs-tab="`#tabs-${tab.id}`"
          :aria-controls="`tabs-${tab.id}`"
          role="tab"
        >
          <Icon :icon="tab.icon" />
          {{ tab.label }}
        </button>
      </nav>

      <div class="relative mx-auto mt-8 max-w-5xl">
        <div
          v-for="tab in usecasesData"
          :key="tab.id"
          :id="`tabs-${tab.id}`"
          :class="[!tab.active ? 'hidden' : 'transition-all duration-300']"
          role="tabpanel"
          :aria-labelledby="`tabs-item-${tab.id}`"
        >
          <div class="shadow-default-200/50 relative overflow-hidden rounded-2xl shadow-2xl">
            <img :src="tab.image" class="h-92 w-full object-cover lg:h-138" :alt="tab.label" />
            <div
              class="bg-default-900/60 absolute right-2 bottom-2 w-70 rounded-3xl border border-white/10 p-3.5 text-left backdrop-blur-md md:right-4 md:bottom-4 md:w-100 md:p-5 lg:right-8 lg:bottom-8 lg:p-7.5"
            >
              <p class="text-default-300 mb-7.5 text-sm font-medium tracking-normal md:text-lg">
                {{ tab.description }}
              </p>
              <div class="flex items-center justify-between">
                <h3 class="text-2xl leading-none font-bold text-white md:text-4xl">
                  {{ tab.value }}
                </h3>
                <p class="text-default-400 text-sm font-medium tracking-tighter">
                  {{ tab.valueLabel }}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="mt-6 md:mt-12.5">
        <p class="text-default-800 mb-2.5 text-sm font-medium">
          And for every kind of daily rhythm
        </p>
        <div class="flex flex-wrap justify-center gap-2.5 md:gap-6.5">
          <span
            v-for="rhythm in rhythmsData"
            :key="rhythm"
            class="text-default-900 text-sm font-medium transition-colors"
          >
            {{ rhythm }}
          </span>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'

type UsecaseType = {
  id: number
  icon: string
  label: string
  image: string
  description: string
  value: string
  valueLabel: string
  active?: boolean
}

const usecasesData: UsecaseType[] = [
  {
    id: 1,
    icon: 'lucide:briefcase-business',
    label: 'Professionals',
    image: '/images/gallery/step-image-01.webp',
    description: 'For people balancing classes, projects, and long study sessions.',
    value: '14',
    valueLabel: 'Study sessions logged each week',
    active: true,
  },
  {
    id: 2,
    icon: 'lucide:graduation-cap',
    label: 'Students',
    image: '/images/gallery/step-image-02.webp',
    description: 'For people juggling work, family routines, and personal goals.',
    value: '12',
    valueLabel: 'Routines completed weekly',
  },
  {
    id: 3,
    icon: 'lucide:briefcase-business',
    label: 'Remote Workers',
    image: '/images/gallery/step-image-03.webp',
    description: 'Focus blocks, breaks, and shutdown routines help keep momentum.',
    value: '40',
    valueLabel: 'Sessions completed monthly',
  },
  {
    id: 4,
    icon: 'lucide:users',
    label: 'Busy Parents',
    image: '/images/gallery/step-image-04.webp',
    description: 'For anyone handling long workdays, shifting priorities, and tight deadlines.',
    value: '87%',
    valueLabel: 'Weekly consistency',
  },
]

const rhythmsData: string[] = [
  '#fitness enthusiasts',
  '#creatives',
  '#entrepreneurs',
  '#freelancers',
  '#new habit builders',
  '#deep-work lovers',
]
</script>
