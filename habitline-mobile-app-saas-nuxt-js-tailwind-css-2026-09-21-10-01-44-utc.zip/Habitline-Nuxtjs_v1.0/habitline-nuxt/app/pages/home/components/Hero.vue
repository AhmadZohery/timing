<template>
  <section
    class="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-black pt-34 md:pt-40 lg:pt-52"
  >
    <img
      src="/images/hero-image.jpg"
      alt="Hero Background"
      class="absolute inset-0 h-full w-full object-cover object-center"
    />
    <div class="relative z-10 container mx-auto px-4">
      <div class="flex flex-col items-center text-center">
        <div
          class="mb-4.5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 p-1.5 pe-2 backdrop-blur-md lg:w-70"
        >
          <span class="rounded-full bg-black px-2 py-px text-base font-medium text-white">New</span>
          <span class="text-sm text-white">A calmer way to build habits</span>
        </div>
        <h1
          class="mb-5 text-4xl leading-tight font-medium tracking-tight text-white md:text-5xl lg:mb-7.5 lg:text-[90px]"
        >
          Build habits that
          <br class="hidden lg:block" />
          actually stick
        </h1>
        <p class="mb-6 max-w-sm text-lg leading-normal text-white md:text-xl lg:mb-10">
          You see the right habits at the right time, so your day never feels crowded.
        </p>
        <div class="flex items-center justify-center gap-2 md:gap-5">
          <NuxtLink
            to="/contact"
            class="group relative overflow-hidden rounded-full bg-white px-3.5 py-3 text-sm font-medium text-black transition-all duration-300 hover:scale-95 md:px-8.5 md:py-4 md:text-lg"
          >
            <span class="relative block overflow-hidden">
              <span class="block transition-transform duration-300 group-hover:-translate-y-full"
                >Start Tracking Free</span
              >
              <span
                class="absolute top-full left-0 block transition-transform duration-300 group-hover:-translate-y-full"
                >Start Tracking Free</span
              >
            </span>
          </NuxtLink>
          <a
            v-lightgallery
            href="https://www.youtube.com/embed/elgqxmdVms8?si=yYfzbunShGP15tde"
            data-toggle="video"
            class="group relative overflow-hidden rounded-full border border-white/20 bg-white/5 px-3.5 py-3 text-sm text-white backdrop-blur-md transition-all duration-300 hover:scale-95 hover:bg-white/10 md:px-8.5 md:py-4 md:text-lg"
          >
            <div class="relative flex items-center gap-3 overflow-hidden">
              <div
                class="flex items-center gap-3 transition-transform duration-300 group-hover:-translate-y-full"
              >
                <Icon icon="tabler:player-play-filled" class="size-4 text-white md:size-6" />
                <span class="font-medium">Watch Demo</span>
              </div>
              <div
                class="absolute top-full left-0 flex items-center gap-3 transition-transform duration-300 group-hover:-translate-y-full"
              >
                <Icon icon="tabler:player-play-filled" class="size-4 text-white md:size-6" />
                <span class="font-medium">Watch Demo</span>
              </div>
            </div>
          </a>
        </div>
        <div
          class="relative mt-6 flex w-full max-w-5xl items-start justify-center gap-8 md:mt-16 md:gap-5 lg:mt-20 lg:gap-10"
        >
          <img
            src="/images/workspace/dashboard-01.svg"
            alt="Dashboard"
            class="absolute inset-s-0 top-8 size-35 md:inset-s-6 lg:inset-s-32 lg:size-40"
          />
          <img
            src="/images/workspace/dashboard-03.svg"
            alt="Dashboard"
            class="relative -z-20! mt-34 h-144 w-75 md:mt-0 lg:w-90"
          />
          <img
            src="/images/workspace/dashboard-02.svg"
            alt="Dashboard"
            class="absolute inset-e-0 top-8 w-50 md:bottom-60 lg:inset-e-14 lg:w-60"
          />
        </div>
      </div>
    </div>
    <div class="bg-body-bg absolute bottom-0 z-20 h-18 w-full md:h-40"></div>
    <img
      src="/images/vector-01.webp"
      alt=""
      class="absolute top-auto -bottom-7.5 z-20 h-70 w-full md:h-100 lg:h-110"
    />
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'
</script>
