<template>
  <section id="features" class="relative pb-8 md:pb-25 lg:pb-50">
    <div class="container">
      <div class="mb-12.5 grid grid-cols-1 items-center gap-3.5 md:grid-cols-2 lg:gap-8">
        <div>
          <div class="mb-3.5 inline-flex">
            <span
              class="border-default-200 text-default-800 inline-block rounded-full border bg-white px-5 py-1.5 text-sm font-medium"
              >Habits with structure</span
            >
          </div>
          <h2 class="text-3xl leading-tight font-medium md:text-4xl lg:w-lg lg:text-5xl">
            A layout that keeps your day clear.
          </h2>
        </div>
        <div>
          <p class="text-default-600 float-end text-lg leading-normal lg:w-md">
            Habitline brings clarity to your routines with clean cards, realistic progress tracking,
            and guidance that adapts to your day.
          </p>
        </div>
      </div>

      <div class="grid grid-cols-1 gap-7.5 lg:grid-cols-2">
        <div class="bg-default-200 overflow-hidden rounded-3xl">
          <div class="px-3.5 py-3.5 md:px-5 md:py-5 lg:px-10 lg:pt-10 lg:pb-12.5">
            <h3 class="text-default-800 mb-2.5 text-xl font-semibold md:text-2xl">
              Flexible Streak Rules
            </h3>
            <p class="text-default-600 max-w-md text-lg">
              Traditional habit trackers are too rigid. Miss one day and your 50-day streak is gone
              forever.
            </p>
          </div>
          <div class="relative mb-7.5 overflow-hidden">
            <img
              src="/images/workspace/dashboard-09.png"
              alt="Dashboard Image"
              class="mx-auto w-62 rounded-lg object-cover md:h-75 md:w-100"
            />
          </div>
          <div class="relative overflow-hidden">
            <div class="animate-marquee flex w-max gap-5 pb-5 lg:pb-20">
              <div
                v-for="item in featuresData"
                :key="item.title"
                class="flex items-center gap-3 rounded-full bg-white py-2.5 ps-2.5 pe-5 backdrop-blur-sm"
              >
                <div
                  :class="['flex size-8 items-center justify-center rounded-full', item.bgClass]"
                >
                  <img :src="item.icon" alt="" class="size-3.25" />
                </div>
                <span class="text-default-800 text-sm font-medium whitespace-nowrap">{{
                  item.title
                }}</span>
              </div>
            </div>
          </div>
        </div>

        <div
          class="flex flex-col gap-y-5 rounded-3xl bg-[url('/images/locations/feature-01.webp')] p-3.5 md:p-5 lg:gap-y-12.5 lg:p-10"
        >
          <div>
            <h3 class="mb-2.5 text-xl font-semibold text-white md:text-2xl">Smart Daily Planner</h3>
            <p class="text-lg text-gray-400 lg:w-md">
              A simple view that shows only the habits that match your current time of day.
            </p>
          </div>
          <div
            class="w-full rounded-3xl border border-white/30 bg-transparent text-white backdrop-blur-xl lg:max-w-xl"
          >
            <div class="mb-7.5 flex items-start justify-between border-b border-white/30 p-5">
              <div>
                <h2 class="text-lg font-medium tracking-normal text-white">Good Morning!</h2>
                <p class="text-default-400 text-sm">Tuesday, 25 Nov</p>
              </div>
              <div class="flex items-center gap-2">
                <span
                  class="border-default-800 rounded-full border bg-black/60 px-3 py-1 text-sm font-bold"
                  >15%</span
                >
                <span class="text-default-300 text-sm font-medium">Completion</span>
              </div>
            </div>
            <div class="space-y-4 pe-4 pb-5 md:pe-10">
              <div class="group flex items-stretch gap-4">
                <div class="relative flex w-16 flex-col items-end justify-center">
                  <div class="text-default-300 text-right text-sm leading-none font-bold">
                    07:30
                    <br />
                    AM
                  </div>
                </div>
                <div
                  class="bg-primary-2/30 border-primary-2/20 flex grow items-center justify-between rounded-xl border p-3.5 transition-transform"
                >
                  <div class="flex items-center gap-2">
                    <div>
                      <Icon icon="lucide:circle-check" class="text-primary-2 size-3.5" />
                    </div>
                    <span class="text-sm font-medium md:text-base">Morning walk</span>
                  </div>
                  <span class="text-default-200 text-xs md:text-sm">15 minutes</span>
                </div>
              </div>
              <div class="group flex items-stretch gap-4">
                <div class="relative flex w-16 flex-col items-end justify-center">
                  <div class="text-default-300 text-right text-sm leading-none font-bold">
                    09:00
                    <br />
                    AM
                  </div>
                </div>
                <div
                  class="bg-primary-2/30 border-primary-2/20 flex grow items-center justify-between rounded-xl border p-3.5 transition-transform"
                >
                  <div class="flex items-center gap-2">
                    <div>
                      <Icon icon="lucide:circle-check" class="text-primary-2 size-3.5" />
                    </div>
                    <span class="text-sm font-medium md:text-base">Drink 3 glasses of water</span>
                  </div>
                  <span class="text-default-200 text-xs md:text-sm">Before 11:00 AM</span>
                </div>
              </div>
              <div class="group flex items-stretch gap-4">
                <div class="relative flex w-16 flex-col items-end justify-center">
                  <div
                    class="text-default-300 text-right text-sm leading-none font-bold text-white"
                  >
                    08:15
                    <br />
                    PM
                  </div>
                </div>
                <div
                  class="bg-default-900 border-default-700 flex grow items-center justify-between rounded-xl border p-3.5 transition-transform"
                >
                  <span class="ms-2 text-sm font-medium md:text-base">Read 10 pages</span>
                  <span class="text-xs text-white md:text-sm">Evening focus block</span>
                </div>
              </div>
              <div class="group flex items-stretch gap-4">
                <div class="relative flex w-16 flex-col items-end justify-center">
                  <div
                    class="text-default-300 text-right text-sm leading-none font-bold text-white"
                  >
                    09:45
                    <br />
                    AM
                  </div>
                </div>
                <div
                  class="bg-default-900 border-default-700 flex grow items-center justify-between rounded-xl border p-3.5 transition-transform"
                >
                  <span class="ms-2 text-sm font-medium md:text-base">Stretch routine</span>
                  <span class="text-xs text-white md:text-sm">5 minutes</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="lg:col-span-2">
          <div
            class="relative overflow-hidden rounded-2xl bg-black bg-[url('/images/locations/feature-02.webp')] p-3.5 md:p-5 lg:p-10"
          >
            <div class="absolute inset-0 bg-black/40"></div>
            <div class="relative z-10 grid grid-cols-1 items-center gap-6 md:grid-cols-2 md:gap-10">
              <div class="flex h-full flex-col justify-between">
                <div class="lg:max-w-md">
                  <h3 class="mb-2.5 text-xl leading-tight font-semibold text-white md:text-2xl">
                    Routine Stacks
                  </h3>
                  <p class="text-default-400 mb-5 text-base leading-relaxed md:mb-7.5 md:text-lg">
                    Group habits into simple blocks so your day feels organized instead of
                    scattered.
                  </p>
                  <NuxtLink
                    to="/contact"
                    class="group relative inline-flex overflow-hidden rounded-full bg-white px-3.5 py-3 text-sm font-medium text-black transition-all duration-300 hover:scale-95 md:px-8.5 md:py-3 md:text-lg"
                  >
                    <span class="relative block overflow-hidden">
                      <span
                        class="block transition-transform duration-300 group-hover:-translate-y-full"
                        >Start your routine now</span
                      >
                      <span
                        class="absolute top-full left-0 block transition-transform duration-300 group-hover:-translate-y-full"
                        >Start your routine now</span
                      >
                    </span>
                  </NuxtLink>
                </div>
                <p class="text-default-500 mt-5 text-sm md:mt-14">
                  *Simple blocks help you stay on track without thinking.
                </p>
              </div>
              <div class="relative flex items-end justify-center lg:justify-end">
                <img
                  src="/images/workspace/dashboard-12.svg"
                  alt="Dashboard"
                  class="z-30 -mb-68 w-60 object-contain pt-5 md:h-125 md:w-97 lg:h-160"
                />
                <img
                  src="/images/workspace/dashboard-11.svg"
                  alt="Floating Card"
                  class="absolute inset-e-65 top-20 z-30 size-25 md:top-25 lg:inset-e-82 lg:size-45"
                />
                <div
                  class="absolute inset-0 bg-gradient-to-l from-transparent via-transparent to-black/40"
                ></div>
              </div>
            </div>
          </div>
        </div>

        <div
          class="relative overflow-hidden rounded-3xl bg-[url('/images/locations/feature-03.webp')] p-3.5 md:p-5 lg:p-10"
        >
          <div
            class="absolute inset-0 bg-gradient-to-b from-black/30 via-black/50 to-black/80"
          ></div>
          <div class="relative z-10">
            <div class="mb-6 max-w-2xl md:mb-12.5">
              <h3 class="mb-2.5 text-xl leading-tight font-semibold text-white md:text-2xl">
                Weekly Reflection
              </h3>
              <p class="text-default-300 text-base leading-relaxed md:w-sm md:text-lg">
                A clear div of your week that highlights what improved and what needs adjusting.
              </p>
            </div>
            <div class="mx-auto max-w-5xl rounded-3xl bg-black/85 p-7.5 backdrop-blur-xl">
              <h4 class="text-center text-base font-semibold text-white md:text-lg">
                Your Week At A Glance
              </h4>
              <div class="mt-7.5 grid grid-cols-2 gap-7.5 text-center md:grid-cols-3">
                <div class="flex flex-col items-center">
                  <div class="relative flex items-center justify-center">
                    <img src="/images/icons/icon-46.svg" alt="Workout" class="size-20" />
                    <div class="absolute flex items-center text-white">
                      <span class="text-xl font-medium">86</span>
                      <span class="mb-1 text-lg font-medium">%</span>
                    </div>
                  </div>
                  <p class="text-default-300 mt-3.5 text-base md:text-lg">Workout</p>
                </div>
                <div class="flex flex-col items-center">
                  <div class="relative flex items-center justify-center">
                    <img
                      src="/images/icons/icon-47.svg"
                      alt="Meditation"
                      class="size-20 md:size-30"
                    />
                    <div class="absolute flex items-center text-white">
                      <span class="text-xl font-medium">100</span>
                      <span class="mb-1 text-xl font-medium">%</span>
                    </div>
                  </div>
                  <p class="text-default-300 mt-3.5 text-base md:text-lg">Meditation</p>
                </div>
                <div class="flex flex-col items-center">
                  <div class="relative flex items-center justify-center">
                    <img src="/images/icons/icon-48.svg" alt="Reading" class="size-20" />
                    <div class="absolute flex items-center text-white">
                      <span class="text-xl font-medium">71</span>
                      <span class="mb-1 text-lg font-medium">%</span>
                    </div>
                  </div>
                  <p class="text-default-300 mt-3.5 text-base md:text-lg">Reading</p>
                </div>
              </div>
            </div>
            <div class="mt-7.5 grid grid-cols-2 gap-2 md:gap-7.5">
              <div class="rounded-2xl border border-white/10 bg-black/40 p-5 backdrop-blur-xl">
                <div class="items-start gap-6 md:flex md:justify-between">
                  <div>
                    <p class="text-lg leading-snug text-white">
                      Streaks
                      <br />
                      Completed
                    </p>
                  </div>
                  <h3 class="text-2xl font-semibold text-white md:text-3xl lg:text-4xl">12</h3>
                </div>
                <p class="text-default-400 mt-4 text-lg md:mt-7.5">3 streaks improved</p>
              </div>
              <div class="rounded-2xl border border-white/10 bg-black/40 p-5 backdrop-blur-xl">
                <div class="items-start gap-6 md:flex md:justify-between">
                  <div>
                    <p class="text-lg leading-snug text-white">focused sessions</p>
                  </div>
                  <h3 class="text-2xl font-semibold text-white md:text-3xl lg:text-4xl">7</h3>
                </div>
                <p class="text-default-400 mt-4 text-lg md:mt-7.5">Total time: 4h 20m</p>
              </div>
            </div>
          </div>
        </div>

        <div class="bg-default-900 relative overflow-hidden rounded-3xl p-5 lg:p-10">
          <div
            class="bg-primary/10 absolute top-1/2 left-1/2 size-125 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl"
          ></div>
          <div class="relative z-10">
            <div class="max-w-xl">
              <h3 class="mb-2.5 text-xl leading-tight font-semibold text-white md:text-2xl">
                Gentle Reminders
              </h3>
              <p class="text-default-300 w-sm text-lg leading-relaxed">
                Short, calm nudges that help you stay consistent without pushing too hard.
              </p>
            </div>
            <div class="relative mt-6 flex justify-center lg:mt-14">
              <div class="absolute top-1/2 z-20 w-full max-w-md -translate-y-1/2 rounded-2xl p-6">
                <div class="absolute -top-20 left-0 rotate-[-20deg] md:-top-22 md:left-4">
                  <div class="relative">
                    <img
                      src="/images/icons/bell-image.png"
                      alt="Bell"
                      class="size-10 object-contain md:size-18"
                    />
                    <div
                      class="bg-primary-7 absolute top-2 right-2 hidden size-7 items-center justify-center rounded-full text-xs font-bold text-white md:flex"
                    >
                      7
                    </div>
                  </div>
                </div>
              </div>
              <img
                src="/images/workspace/dashboard-13.svg"
                loading="lazy"
                alt="Dashboard Image"
                class="mt-6 h-54 w-90 md:mt-12"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { NuxtLink } from '#components'

type FeatureType = {
  title: string
  icon: string
  bgClass: string
}

const featuresData: FeatureType[] = [
  {
    title: 'Travel Mode Active',
    icon: '/images/icons/icon-42.svg',
    bgClass: 'bg-primary-1',
  },
  {
    title: 'Sick Day Allowance',
    icon: '/images/icons/icon-43.svg',
    bgClass: 'bg-primary-6',
  },
  {
    title: 'Weekend Flexibility',
    icon: '/images/icons/icon-44.svg',
    bgClass: 'bg-primary-8',
  },
  {
    title: 'Morning walk',
    icon: '/images/icons/icon-12.svg',
    bgClass: 'bg-primary-2',
  },
  {
    title: 'Focus session',
    icon: '/images/icons/icon-13.svg',
    bgClass: 'bg-primary-3',
  },
  {
    title: 'Meditate',
    icon: '/images/icons/icon-16.svg',
    bgClass: 'bg-primary-4',
  },
  {
    title: 'Track water',
    icon: '/images/icons/icon-17.svg',
    bgClass: 'bg-primary-7',
  },
]
</script>
